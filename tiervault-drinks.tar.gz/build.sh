set -e
O=.vercel/output
rm -rf $O && mkdir -p $O/static $O/functions/api.func
cp -r site/. $O/static/
cp api/index.js $O/functions/api.func/index.js
printf '{"runtime":"nodejs22.x","handler":"index.js","launcherType":"Nodejs","shouldAddHelpers":true,"maxDuration":10}' > $O/functions/api.func/.vc-config.json
printf '{"version":3,"routes":[{"handle":"filesystem"}]}' > $O/config.json
