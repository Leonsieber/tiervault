/* Tier Vault – cinema preview (CineStar Konstanz) */
const KINO_API='https://www.cinestar.de/api/cinema/32/';
const KINO_SITE='https://www.cinestar.de';
let kino={state:{},map:{}};            // saved: state[id] = 'watch' | 'seen' | 'dismissed'; map[id] = movie item id
let kinoCache=null;                      // {at, films:[...]}
let kinoView={filter:'all',showHidden:false,loading:false,error:false};
let inKino=false;

function normKino(k){const o={state:{},map:{}}; if(k&&typeof k==='object'){ if(k.state&&typeof k.state==='object') for(const [a,b] of Object.entries(k.state)) if(['watch','seen','dismissed'].includes(b)) o.state[a]=b; if(k.map&&typeof k.map==='object') Object.assign(o.map,k.map);} return o}
function kinoYmd(s){const m=String(s||'').match(/(\d{4})-(\d{2})-(\d{2})/); return m?`${m[1]}-${m[2]}-${m[3]}`:''}
function kinoDate(s){const m=String(s||'').match(/(\d{4})-(\d{2})-(\d{2})/); return m?new Date(+m[1],+m[2]-1,+m[3]):null}
function dayStart(d){return new Date(d.getFullYear(),d.getMonth(),d.getDate())}
const KINO_FMT=new Intl.DateTimeFormat('en-GB',{weekday:'short',day:'numeric',month:'short'});
const KINO_DAYS=92;

async function fetchKino(){
  const [shows,prev]=await Promise.all([getJSON(KINO_API+'show/?appVersion=1.5.3'), getJSON(KINO_API+'preview/?appVersion=1.5.3').catch(()=>[])]);
  const today=dayStart(new Date()); const until=new Date(today.getTime()+KINO_DAYS*864e5);
  const films=new Map();
  for(const s of (Array.isArray(shows)?shows:[])){
    if(s._type!=='movie') continue;
    const id=String(s.movie||s.id); const start=kinoDate(s.startDate||s.date); if(!start) continue;
    const playing=start<=today && (s.showtimes||[]).length>0;
    const soon=start>today && start<=until;
    if(!playing&&!soon) continue;
    const fsk=((Array.isArray(s.attributes)?s.attributes:[]).find(a=>/^FSK_\d+/.test(a))||'').replace('FSK_','');
    films.set(id,{id,title:s.title,start:kinoYmd(s.startDate||s.date),poster:s.poster||s.poster_preload||'',link:s.detailLink||'',genres:(Array.isArray(s.genres)?s.genres:[]).slice(0,2),fsk,playing});
  }
  for(const p of (Array.isArray(prev)?prev:[])){
    const id=String(p.movie||p.id); if(films.has(id)) continue;
    const start=kinoDate(p.datetime); if(!start||start<=today||start>until) continue;
    films.set(id,{id,title:p.title,start:kinoYmd(p.datetime),poster:p.poster||p.poster_preload||'',link:p.detailLink||'',genres:[],fsk:'',playing:false});
  }
  return [...films.values()].sort((a,b)=>a.start.localeCompare(b.start)||a.title.localeCompare(b.title));
}
async function refreshKino(force){
  const fresh=kinoCache&&Date.now()-kinoCache.at<30*60e3;
  if(kinoView.loading||(fresh&&!force)) return;
  kinoView.loading=true; kinoView.error=false; if(inKino) renderKino();
  try{ const films=await fetchKino(); kinoCache={at:Date.now(),films,en:(kinoCache&&kinoCache.en)||{}}; Store.write('kino-cache',kinoCache).catch(()=>{}); resolveKinoTitles(); }
  catch(e){ kinoView.error=true; }
  kinoView.loading=false; if(inKino) renderKino(); else if(!current) renderHome();
}

/* ---- adding a cinema film to the movie ranking ---- */
function titleParts(de){return [de,...String(de).split(/\s+[-–:]\s+/).filter(x=>x&&x!==de&&x.length>=5)]}
async function englishTitle(de,year){
  try{
    const p=new URLSearchParams({action:'query',generator:'search',gsrsearch:de+' Film',gsrlimit:'8',prop:'langlinks|description',lllang:'en',format:'json',formatversion:'2',origin:'*'});
    const j=await getJSON('https://de.wikipedia.org/w/api.php?'+p);
    const pages=((j.query&&j.query.pages)||[]).sort((a,b)=>a.index-b.index);
    const b=norm(de);
    for(const pg of pages){
      const isFilm=/\((\d{4} )?Film\)|Film$/.test(pg.title)||/film/i.test(pg.description||'');
      if(!isFilm) continue;
      if(year&&/\((\d{4})/.test(pg.title)&&!pg.title.includes(year)) continue;
      const a=norm(pg.title.replace(/\(.*?\)/g,''));
      if(!(a===b||(b.startsWith(a)&&a.length>=b.length*0.6)||(a.startsWith(b)&&b.length>=a.length*0.6))) continue;
      const en=pg.langlinks&&pg.langlinks[0]&&pg.langlinks[0].title;
      if(!en||/(franchise|series|list of|soundtrack|novel)/i.test(en)) continue;
      return {t:en.replace(/\s*\((\d{4} )?[^)]*film\)$/i,'').trim(), y:(en.match(/\((\d{4})/)||[])[1]||''};
    }
  }catch(e){}
  for(const part of titleParts(de)){
    try{ const r=(await wikiSearch(part,'movie')).find(x=>x.year===year&&norm(x.title)===norm(part)); if(r) return {t:r.title,y:(r.key.match(/\((\d{4})/)||[])[1]||''} }catch(e){}
  }
  return null;
}
async function kinoToMovies(f,asLibrary){
  if(!lists.movies) return null;
  const L=lists.movies; const year=f.start.slice(0,4);
  let item=(kino.map[f.id]&&catItems('movies').find(i=>i.id===kino.map[f.id]))||null;
  if(!item){ for(const part of titleParts(f.title)){ item=findExisting('movies',part,''); if(item) break; } }
  let title=f.title;
  const cachedEn=kinoCache&&kinoCache.en&&kinoCache.en[f.id];
  if(!item&&cachedEn){ title=cachedEn; item=findExisting('movies',cachedEn,''); }
  if(!item&&!cachedEn){
    const en=await englishTitle(f.title,year);
    if(en){
      title=en.t; const ex=findExisting('movies',en.t,'');
      if(ex&&en.y&&ex.y&&ex.y!==en.y){ title=`${en.t} (${en.y})`; item=findExisting('movies',title,''); }
      else item=ex;
    }
  }
  if(!item){
    const id='k-'+f.id;
    if(!L.custom.find(c=>c.id===id)) L.custom.push({id,t:title,y:year,lib:asLibrary?1:0});
    if(f.poster&&!covers[id]){try{covers[id]=await blobToPoster(await getBlob(f.poster)); saveCovers()}catch(e){}}
    item=catItems('movies').find(i=>i.id===id);
  }
  kino.map[f.id]=item.id;
  if(!asLibrary){
    if(item.x&&!L.added.includes(item.id)) L.added.push(item.id);
    L.hidden=L.hidden.filter(h=>h!==item.id);
    if(item.custom){const c=L.custom.find(c=>c.id===item.id); if(c) c.lib=0;}
  }
  save('movies');
  return item;
}

/* ---- English titles for the preview ---- */
let resolvingTitles=false;
async function resolveEnTitle(f){
  const year=f.start.slice(0,4);
  for(const part of titleParts(f.title)){ const ex=findExisting('movies',part,''); if(ex) return ex.t; }
  const en=await englishTitle(f.title,year);
  if(!en) return null;
  const ex=findExisting('movies',en.t,'');
  if(ex&&en.y&&ex.y&&ex.y!==en.y) return `${en.t} (${en.y})`;
  return ex?ex.t:en.t;
}
async function resolveKinoTitles(){
  if(resolvingTitles||!kinoCache) return; resolvingTitles=true;
  kinoCache.en=kinoCache.en||{};
  const todo=kinoCache.films.filter(f=>!(f.id in kinoCache.en));
  let changed=0;
  await Promise.all(Array.from({length:3},async()=>{while(todo.length){const f=todo.shift(); let t=null; try{t=await resolveEnTitle(f)}catch(e){} kinoCache.en[f.id]=t; changed++; if(changed%4===0&&inKino) renderKino();}}));
  resolvingTitles=false;
  if(changed){ Store.write('kino-cache',kinoCache).catch(()=>{}); if(inKino) renderKino(); else if(!current) renderHome(); }
}
function kTitle(f){return (kinoCache&&kinoCache.en&&kinoCache.en[f.id])||f.title}
const KINO_LONG=new Intl.DateTimeFormat('en-GB',{weekday:'short',day:'numeric',month:'short',year:'numeric'});

/* ---- view ---- */
function openKino(){
  inKino=true; current=null; selected=null; hideMovebar();
  renderKino(); window.scrollTo(0,0);
  refreshKino(false); resolveKinoTitles();
}
function kinoCard(f){
  const st=kino.state[f.id]||'';
  const d=new Date(f.start+'T00:00:00');
  const title=kTitle(f);
  const meta=[f.genres.join(', '),f.fsk?('FSK '+f.fsk):''].filter(Boolean).join(' · ');
  const img=f.poster?`<img src="${esc(f.poster)}" alt="" loading="lazy" referrerpolicy="no-referrer">`:`<div class="ph" style="background:hsl(${hue(title)},45%,32%)">${esc(title)}</div>`;
  const tip=title!==f.title?`${title} (German: ${f.title})`:title;
  return `<div class="kcard${st==='watch'?' watch':''}" data-kid="${esc(f.id)}" tabindex="0" title="${esc(tip)}">
    <div class="kposter">${img}${f.playing?'<span class="kdate">Now showing</span>':''}${st==='watch'?'<span class="kflag">To watch</span>':''}</div>
    <div class="ktxt"><b>${esc(title)}</b><span class="kstart">${f.playing?'In cinemas since':'Release'} ${esc(KINO_LONG.format(d))}</span>${meta?`<span>${esc(meta)}</span>`:''}</div>
    ${f.link?`<button class="klink" data-link="${esc(f.link)}" title="Trailer and tickets on cinestar.de">Details ↗</button>`:''}
  </div>`;
}
function renderKino(){
  if(!inKino) return;
  const films=(kinoCache&&kinoCache.films)||[];
  const visible=films.filter(f=>!['seen','dismissed'].includes(kino.state[f.id]));
  const shown=kinoView.filter==='watch'?visible.filter(f=>kino.state[f.id]==='watch'):visible;
  const nWatch=visible.filter(f=>kino.state[f.id]==='watch').length;
  const hidden=films.filter(f=>['seen','dismissed'].includes(kino.state[f.id]));
  const playing=shown.filter(f=>f.playing), soon=shown.filter(f=>!f.playing);
  const groups=[]; for(const f of soon){const g=groups[groups.length-1]; if(g&&g.start===f.start) g.items.push(f); else groups.push({start:f.start,items:[f]})}
  const upd=kinoCache?new Date(kinoCache.at):null;
  const status=kinoView.loading?'<span class="spin"></span>Updating…':kinoView.error?'Could not reach CineStar. Showing the last saved list.':upd?`Updated ${upd.toLocaleString('en-GB',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})}`:'';
  let body='';
  if(!films.length){
    body=kinoView.loading?'<div class="hint"><span class="spin"></span>Loading the program from CineStar Konstanz…</div>':'<div class="hint">No program loaded yet. Check the internet connection and press “Refresh”.</div>';
  } else {
    if(playing.length) body+=`<h3 class="ksec">Now showing <span>${playing.length}</span></h3><div class="kgrid">${playing.map(kinoCard).join('')}</div>`;
    if(groups.length){ body+=`<h3 class="ksec">Coming soon <span>${soon.length}</span></h3>`;
      body+=groups.map(g=>`<div class="kgroup"><div class="kday">${esc(KINO_FMT.format(new Date(g.start+'T00:00:00')))}</div><div class="kgrid">${g.items.map(kinoCard).join('')}</div></div>`).join(''); }
    if(!playing.length&&!groups.length) body+=`<div class="hint">${kinoView.filter==='watch'?'Nothing on your watchlist yet. Left-click a poster to add it.':'Nothing left here. Everything is on your watchlist, seen or removed.'}</div>`;
    if(hidden.length){
      body+=`<div class="khidden"><button class="btn ghost" id="toggleHidden">${kinoView.showHidden?'Hide':'Show'} seen and removed (${hidden.length})</button>`;
      if(kinoView.showHidden) body+=`<div class="klist">${hidden.map(f=>`<div class="kh"><span>${esc(kTitle(f))}</span><small>${kino.state[f.id]==='seen'?'Seen, in Movies':'Removed'}</small><button class="btn" data-restore="${esc(f.id)}">Put back</button></div>`).join('')}</div>`;
      body+='</div>';
    }
  }
  $('#app').innerHTML=`
  <div class="bar">
    <button class="back" id="back" aria-label="Back to all lists">←</button>
    <h2>Cinema</h2>
    <span class="counts">CineStar Konstanz · next 3 months</span>
    <span class="spacer"></span>
    <span class="status" id="kstatus">${status}</span>
    <div class="seg"><button data-kf="all" aria-pressed="${kinoView.filter==='all'}">All · ${visible.length}</button><button data-kf="watch" aria-pressed="${kinoView.filter==='watch'}">Watchlist · ${nWatch}</button></div>
    <button class="btn" id="kRefresh"${kinoView.loading?' disabled':''}>↻ Refresh</button>
    <button class="btn icon" id="openSettings" aria-label="Settings">${gear()}</button>
  </div>
  ${body}`;
  $('#back').onclick=()=>{inKino=false;renderHome()};
  $('#openSettings').onclick=openSheet;
  $('#kRefresh').onclick=()=>refreshKino(true);
  $('#app').querySelectorAll('[data-kf]').forEach(b=>b.onclick=()=>{kinoView.filter=b.dataset.kf;renderKino()});
  const th=$('#toggleHidden'); if(th) th.onclick=()=>{kinoView.showHidden=!kinoView.showHidden;renderKino()};
  $('#app').querySelectorAll('[data-restore]').forEach(b=>b.onclick=()=>{delete kino.state[b.dataset.restore]; save(null); renderKino()});
  $('#app').querySelectorAll('.klink').forEach(b=>b.onclick=e=>{e.stopPropagation(); const u=KINO_SITE+b.dataset.link; if(IS_APP) Neutralino.os.open(u); else window.open(u,'_blank')});
  $('#app').querySelectorAll('.kcard').forEach(el=>{
    el.addEventListener('click',e=>{ if(e.target.closest('.klink')) return; kinoLeft(el.dataset.kid) });
    el.addEventListener('contextmenu',e=>{ e.preventDefault(); kinoRight(el.dataset.kid) });
    el.addEventListener('keydown',e=>{ if(e.key==='Enter'){e.preventDefault();kinoLeft(el.dataset.kid)} if(e.key==='Delete'||e.key==='Backspace'){e.preventDefault();kinoRight(el.dataset.kid)} });
  });
}
function kinoFilm(id){return ((kinoCache&&kinoCache.films)||[]).find(f=>f.id===id)}
async function kinoLeft(id){
  const f=kinoFilm(id); if(!f) return; const st=kino.state[id];
  if(!st){ kino.state[id]='watch'; save(null); renderKino(); toast(`“${kTitle(f)}” is on your watchlist`); return; }
  if(st==='watch'){
    kino.state[id]='seen'; save(null); renderKino(); toast(`Adding “${kTitle(f)}” to Movies…`);
    try{ const it=await kinoToMovies(f,false); toast(it?`“${it.t}” is in Movies, ready to rank`:'Added'); }
    catch(e){ toast('Could not add it to Movies. Try again with “Put back”.'); }
  }
}
async function kinoRight(id){
  const f=kinoFilm(id); if(!f) return; const st=kino.state[id];
  if(st==='watch'){ delete kino.state[id]; save(null); renderKino(); toast(`Removed the mark from “${kTitle(f)}”`); return; }
  if(!st){
    kino.state[id]='dismissed'; save(null); renderKino();
    try{ const it=await kinoToMovies(f,true); toast(`Removed “${kTitle(f)}”. It is in the Movies library now.`); }
    catch(e){ toast(`Removed “${kTitle(f)}”`); }
  }
}
function kinoTileHTML(){
  const films=(kinoCache&&kinoCache.films)||[];
  const vis=films.filter(f=>!['seen','dismissed'].includes(kino.state[f.id]));
  const soon=vis.filter(f=>!f.playing); const nWatch=vis.filter(f=>kino.state[f.id]==='watch').length;
  const art=(soon.length>=3?soon:vis).filter(f=>f.poster).slice(0,3);
  const next=soon[0];
  return `<button class="tile kino-tile" data-kino="1" aria-label="Open the cinema preview">
    <div class="fan">${art.map(f=>`<img src="${esc(f.poster)}" alt="" referrerpolicy="no-referrer">`).join('')}</div>
    <h3>Cinema</h3>
    <div class="meta"><span>CineStar Konstanz, next 3 months.</span></div>
    <div class="meter"><span style="width:${vis.length?Math.round(nWatch/vis.length*100):0}%"></span></div>
    <div class="meta"><span><b style="color:var(--ink)">${nWatch}</b> on your watchlist</span><span>${soon.length} coming</span></div>
    ${next?`<div class="top">Next: <b>${esc(kTitle(next))}</b> · ${esc(KINO_FMT.format(new Date(next.start+'T00:00:00')))}</div>`:''}
  </button>`;
}
