/* Tier Vault – desktop app */
const TVD = window.TV_DATA;
const ALL_CATS = {
  movies:  {label:'Movies',  noun:'movies', blurb:'Every film you have seen.', online:'Wikipedia'},
  series:  {label:'Series',  noun:'series', blurb:'Shows, miniseries and anime.', online:'TVmaze'},
  games:   {label:'Games',   noun:'games',  blurb:'Everything you have played.', online:'Steam and Wikipedia'},
  ninjago: {label:'Ninjago', noun:'seasons',blurb:'Every season, chapter and part.', online:null},
  books:   {label:'Books',   noun:'books',  blurb:'Everything you have read.', online:'Open Library and Google Books'},
  drinks:  {label:'Drinks',  noun:'drinks', blurb:'Every can, bottle and cup.', online:'Open Food Facts'}
};
const CATS = Object.fromEntries(TVD.cats.map(c=>[c,ALL_CATS[c]]));
const ITEMS = TVD.items;
const HOME_ART = TVD.home;
const PRESETS = {
  movies:[['All-Time Great','#ffcc33'],['Instant Classic','#ffa630'],['Rewatch Forever','#ff7a45'],['Great Night In','#ff5c8a'],['Really Good','#e05fc8'],['Popcorn Fine','#b07cff'],['Mid','#7f8cff'],['Forgettable','#5aa9ff'],['Regret Watching','#3fb8b0'],['Walked Out','#7d8597'],['Seen Too Long Ago','#c9ced8']],
  series:[['Binged in One Night','#ffcc33'],['Must Watch','#ff7a45'],['Solid Watch','#ff5c8a'],['Background Noise','#b07cff'],['Dropped It','#5aa9ff'],['Painful','#7d8597'],['Still Watching','#c9ced8']],
  games:[['GOAT','#ffcc33'],['No-Lifed It','#ff7a45'],['Great Run','#ff5c8a'],['Casual Fun','#b07cff'],['Uninstalled','#5aa9ff'],['Rage Quit','#7d8597'],['Not Played Enough','#c9ced8']],
  books:[['Life-Changing','#ffcc33'],['Couldn’t Put It Down','#ff7a45'],['Loved It','#ff5c8a'],['Good Read','#b07cff'],['It Was Okay','#5aa9ff'],['Dragged On','#3fb8b0'],['Did Not Finish','#7d8597'],['Read Too Long Ago','#c9ced8']],
  drinks:[['Liquid Gold','#ffcc33'],['Fridge Must-Have','#ff7a45'],['Daily Driver','#ff5c8a'],['Solid Sip','#b07cff'],['Only When Thirsty','#5aa9ff'],['Tastes Like Regret','#3fb8b0'],['Drain Pour','#7d8597'],['Haven’t Had in Ages','#c9ced8']],
  ninjago:[['Golden Master','#ffcc33'],['Spinjitzu Master','#ff5a3c'],['True Ninja','#3ccf6e'],['Apprentice','#3aa0ff'],['Serpentine','#9b6bff'],['Cursed Realm','#6b7280']]
};
const SHORT = {'Secrets of the Forbidden Spinjitzu: Fire Chapter':'Forbidden Spinjitzu: Fire Chapter','Secrets of the Forbidden Spinjitzu: Ice Chapter':'Forbidden Spinjitzu: Ice Chapter'};
for(let s=1;s<=4;s++) for(const p of [1,2]) SHORT[`Dragons Rising: Season ${s} Part ${p}`]=`Dragons Rising S${s} · Part ${p}`;
const ACCENTS = ['#ff4d5e','#ff8a1f','#f5c400','#22c55e','#14b8a6','#3b82f6','#8b5cf6','#ec4899'];

/* ---------- helpers ---------- */
const $ = (s,el=document)=>el.querySelector(s);
const esc = s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function hue(s){let h=0;for(let i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))>>>0;return h%360}
function textOn(hex){const c=hex.replace('#','');const r=parseInt(c.substr(0,2),16),g=parseInt(c.substr(2,2),16),b=parseInt(c.substr(4,2),16);return (r*299+g*587+b*114)/1000>150?'#14161c':'#ffffff'}
const norm = s=>String(s).toLowerCase().replace(/&/g,'and').replace(/\(.*?\)/g,'').replace(/[^a-z0-9]+/g,'');
let toastT; function toast(msg){const t=$('#toast');t.textContent=msg;t.hidden=false;clearTimeout(toastT);toastT=setTimeout(()=>t.hidden=true,2600)}
const IS_APP = typeof window.NL_OS !== 'undefined' && typeof Neutralino !== 'undefined';

/* ---------- storage (a file on this computer; localStorage when run in a plain browser) ---------- */
const Store = {
  dir:null,
  async init(){
    if(!IS_APP) return;
    try{ Neutralino.init(); }catch(e){}
    const base=(await Neutralino.os.getPath('data')).replace(/[\\/]+$/,'');
    this.dir=base+'/TierVault/'+TVD.variant;
    try{await Neutralino.filesystem.createDirectory(base+'/TierVault')}catch(e){}
    try{await Neutralino.filesystem.createDirectory(this.dir)}catch(e){}
  },
  async read(name){
    if(Cloud.user&&(name==='data'||name==='covers')) return Cloud.cache[name];
    if(!IS_APP){try{const v=localStorage.getItem('tv_'+TVD.variant+'_'+name);return v?JSON.parse(v):null}catch(e){return null}}
    try{return JSON.parse(await Neutralino.filesystem.readFile(this.dir+'/'+name+'.json'))}catch(e){return null}
  },
  async write(name,obj){
    if(Cloud.user&&(name==='data'||name==='covers')){ Cloud.cache[name]=obj; return Cloud.save(name,obj); }
    const s=JSON.stringify(obj);
    if(!IS_APP){try{localStorage.setItem('tv_'+TVD.variant+'_'+name,s)}catch(e){}return}
    const f=this.dir+'/'+name+'.json';
    await Neutralino.filesystem.writeFile(f+'.tmp',s);
    try{await Neutralino.filesystem.move(f+'.tmp',f)}catch(e){await Neutralino.filesystem.writeFile(f,s)}
  }
};
const timers={}; let saving=Promise.resolve();
function schedule(name,fn,ms=350){clearTimeout(timers[name]);timers[name]=setTimeout(()=>{delete timers[name];saving=saving.then(fn).catch(e=>{console.error(e);toast(e&&e.message?'Not saved: '+e.message:'Could not save.')})},ms)}
async function flushAll(){for(const k of Object.keys(timers)){clearTimeout(timers[k]);delete timers[k]} await saving; await Store.write('data',{v:1,prefs,lists,kino}); await Store.write('covers',covers);}

/* ---------- state ---------- */
const DEFAULT_PREFS={accent:'#ff4d5e',mode:'auto',size:'m',titles:'on'};
let prefs=Object.assign({},DEFAULT_PREFS);
function freshList(cat){return {tiers:PRESETS[cat].map((p,i)=>({id:'t'+i,label:p[0],color:p[1]})),rank:{},custom:[],added:[],hidden:[],updated:0}}
function normList(cat,l){const f=freshList(cat);if(!l||typeof l!=='object')return f;
  const o={tiers:Array.isArray(l.tiers)&&l.tiers.length?l.tiers.filter(t=>t&&t.id).map(t=>({id:String(t.id),label:String(t.label||''),color:/^#[0-9a-f]{6}$/i.test(t.color)?t.color:'#888888'})):f.tiers,
    rank:{},custom:Array.isArray(l.custom)?l.custom.filter(c=>c&&c.id&&c.t).map(c=>({id:String(c.id),t:String(c.t),y:c.y?String(c.y):'',lib:c.lib?1:0})):[],
    added:Array.isArray(l.added)?l.added.map(String):[],hidden:Array.isArray(l.hidden)?l.hidden.map(String):[],updated:+l.updated||0};
  const tids=new Set(o.tiers.map(t=>t.id));
  if(l.rank&&typeof l.rank==='object')for(const [k,v] of Object.entries(l.rank)) if(tids.has(k)&&Array.isArray(v)) o.rank[k]=v.map(String);
  return o;}
const lists={};
let covers={};
const posters={}; const posterLoads={};
let current=null, tab='rank', query='', selected=null, editTiers=false, dragging=false;

function personalData(){ const l=Object.assign({},lists); if(Cloud.group){const c=Object.keys(CATS)[0]; l[c]=Cloud.personal} return {v:1,prefs,lists:l,kino} }
function save(cat){ if(cat) lists[cat].updated=Date.now(); if(cat&&Cloud.group){saveGroupList(cat);return} schedule('data',()=>Store.write('data',personalData())) }
function savePrefs(){ save(null) }
function saveCovers(){ schedule('covers',()=>Store.write('covers',covers),200) }

function catItems(cat){
  const L=lists[cat]; const base=ITEMS[cat].map(a=>({id:a[0],t:a[1],x:a[2],y:a[3]||''}));
  return base.concat(L.custom.map(c=>({id:c.id,t:c.t,y:c.y,x:c.lib?1:0,custom:true})));
}
function rankedIds(cat){const L=lists[cat];const s=new Set();for(const t of L.tiers)for(const id of (L.rank[t.id]||[]))s.add(id);return s}
function inPool(cat,it){const L=lists[cat]; if(L.hidden.includes(it.id)) return false; return !it.x || L.added.includes(it.id)}

/* ---------- posters ---------- */
function loadPosters(cat){
  if(posters[cat]) return Promise.resolve(posters[cat]);
  posters[cat]=Object.fromEntries(ITEMS[cat].map(a=>[a[0],'posters/'+cat+'/'+a[0]+'.webp']));
  return Promise.resolve(posters[cat]);
}
function imgFor(cat,id){return covers[id]||Cloud.foreignCov[id]||(posters[cat]&&posters[cat][id])||(typeof drinkArt==='function'?drinkArt(id):null)||null}

/* ---------- network: fetch first, curl as a fallback for sites that block apps ---------- */
function curlCmd(){return (window.NL_OS==='Windows')?'curl.exe':'curl'}
function withTimeout(p,ms){return Promise.race([p,new Promise((_,r)=>setTimeout(()=>r(new Error('timeout')),ms))])}
async function getText(url){
  try{const r=await withTimeout(fetch(url),12000); if(!r.ok) throw new Error('http '+r.status); return await r.text()}
  catch(e){ if(!IS_APP) throw e;
    const res=await Neutralino.os.execCommand(`${curlCmd()} -s -L -m 15 -A "TierVault/1.0" "${url}"`);
    if(res.exitCode!==0||!res.stdOut) throw new Error('curl '+res.exitCode); return res.stdOut; }
}
async function getJSON(url){return JSON.parse(await getText(url))}
async function getBlob(url){
  try{const r=await withTimeout(fetch(url,{mode:'cors'}),15000); if(!r.ok) throw new Error('http '+r.status); const b=await r.blob(); if(!b.size||!/^image\//.test(b.type)) throw new Error('not image'); return b}
  catch(e){ if(!IS_APP) throw e;
    const tmp=(await Neutralino.os.getPath('temp')).replace(/[\\/]+$/,'')+'/tv_'+Date.now()+Math.random().toString(36).slice(2,7)+'.img';
    const res=await Neutralino.os.execCommand(`${curlCmd()} -s -L -f -m 20 -A "TierVault/1.0" -o "${tmp}" "${url}"`);
    if(res.exitCode!==0) throw new Error('curl '+res.exitCode);
    const buf=await Neutralino.filesystem.readBinaryFile(tmp); try{await Neutralino.filesystem.remove(tmp)}catch(_){}
    if(!buf.byteLength) throw new Error('empty'); return new Blob([buf]); }
}
async function blobToPoster(blob){
  const i=await createImageBitmap(blob); const W=240,H=360;
  const c=document.createElement('canvas'); c.width=W; c.height=H; const x=c.getContext('2d'); x.fillStyle='#15171d'; x.fillRect(0,0,W,H);
  const ar=i.width/i.height;
  if(ar>0.72||ar<0.6){const s=Math.max(W/i.width,H/i.height); x.filter='blur(14px) brightness(0.5)'; x.drawImage(i,(W-i.width*s)/2,(H-i.height*s)/2,i.width*s,i.height*s); x.filter='none'; const s2=Math.min(W/i.width,H/i.height); x.drawImage(i,(W-i.width*s2)/2,(H-i.height*s2)/2,i.width*s2,i.height*s2);}
  else {const s=Math.max(W/i.width,H/i.height); x.drawImage(i,(W-i.width*s)/2,(H-i.height*s)/2,i.width*s,i.height*s);}
  let u=c.toDataURL('image/webp',0.8); if(!u.startsWith('data:image/webp')) u=c.toDataURL('image/jpeg',0.82); return u;
}

/* ---------- online search ---------- */
const WIKI='https://en.wikipedia.org/w/api.php?format=json&formatversion=2&origin=*&';
async function wikiSearch(q,kind){
  const p=new URLSearchParams({action:'query',generator:'search',gsrsearch:q+(kind==='movie'?' film':' video game'),gsrlimit:'15',prop:'pageimages|description',piprop:'thumbnail',pithumbsize:'480',pilicense:'any'});
  const j=await getJSON(WIKI+p); const pages=(j.query&&j.query.pages)||[];
  pages.sort((a,b)=>a.index-b.index);
  const out=[];
  for(const pg of pages){
    const d=pg.description||''; const t=pg.title;
    if(/^(List of|Music of|Accolades|\d{4} in )/i.test(t)) continue;
    if(kind==='movie'){
      if(!/(\bfilm\b|\bmovie\b|space opera)/i.test(d+' '+t)) continue;
      if(/(director|actor|actress|producer|screenwriter|critic|composer|franchise|film series|novel|soundtrack|character|festival|studio|company|cancelled|television|tv series|list of)/i.test(d)) continue;
    } else {
      if(!/video game/i.test(d)) continue;
      if(/(character|music|soundtrack|designer|composer|developer|publisher|franchise|series|genre|award|esports|competition|programmer|canceled|cancelled|list|engine|console|company)/i.test(d)) continue;
    }
    const clean=t.replace(/\s*\((\d{4} )?(American |British |Indian |Japanese |South Korean |animated )?(film|video game|movie)\)$/i,'').replace(/\s*\((\d{4} )?[^)]*(film|video game)\)$/i,'');
    const y=(t.match(/\((\d{4})/)||d.match(/\b(19\d\d|20\d\d)\b/)||[])[1]||'';
    out.push({key:'w:'+t,title:clean,year:y,sub:d,source:'Wikipedia',preview:pg.thumbnail&&pg.thumbnail.source,imgs:pg.thumbnail?[pg.thumbnail.source]:[]});
  }
  return out;
}
async function tvmazeSearch(q){
  const j=await getJSON('https://api.tvmaze.com/search/shows?q='+encodeURIComponent(q));
  return j.slice(0,12).map(r=>{const s=r.show; const net=(s.network&&s.network.name)||(s.webChannel&&s.webChannel.name)||'';
    return {key:'tvm:'+s.id,title:s.name,year:(s.premiered||'').slice(0,4),sub:[net,(s.genres||[]).slice(0,2).join(', ')].filter(Boolean).join(' · '),source:'TVmaze',
      preview:s.image&&s.image.medium,imgs:s.image?[s.image.original||s.image.medium,s.image.medium]:[]}});
}
async function steamSearch(q){
  const j=await getJSON('https://store.steampowered.com/api/storesearch/?cc=CH&l=english&term='+encodeURIComponent(q));
  return (j.items||[]).filter(i=>i.type==='app'||!i.type).slice(0,10).map(i=>{
    const base='https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/'+i.id+'/';
    return {key:'st:'+i.id,title:i.name.replace(/[™®]/g,''),year:'',sub:'Steam',source:'Steam',preview:i.tiny_image,steamId:i.id,
      imgs:[base+'library_600x900_2x.jpg',base+'library_600x900.jpg']};
  });
}
async function steamHeader(id){try{const j=await getJSON('https://store.steampowered.com/api/appdetails?cc=CH&appids='+id); return j[id]&&j[id].data&&j[id].data.header_image}catch(e){return null}}
async function openLibrarySearch(q){
  const j=await getJSON('https://openlibrary.org/search.json?limit=15&fields=key,title,author_name,first_publish_year,cover_i&q='+encodeURIComponent(q));
  return (j.docs||[]).filter(d=>d.title).map(d=>({key:'ol:'+d.key,title:d.title,year:d.first_publish_year?String(d.first_publish_year):'',
    sub:(d.author_name||[]).slice(0,2).join(', '),source:'Open Library',
    preview:d.cover_i?`https://covers.openlibrary.org/b/id/${d.cover_i}-M.jpg`:null,
    imgs:d.cover_i?[`https://covers.openlibrary.org/b/id/${d.cover_i}-L.jpg`,`https://covers.openlibrary.org/b/id/${d.cover_i}-M.jpg`]:[]}));
}
async function googleBooksSearch(q){
  const j=await getJSON('https://www.googleapis.com/books/v1/volumes?maxResults=12&printType=books&q='+encodeURIComponent(q));
  return (j.items||[]).map(it=>{const v=it.volumeInfo||{}; const img=v.imageLinks&&(v.imageLinks.thumbnail||v.imageLinks.smallThumbnail);
    const u=img?img.replace(/^http:/,'https:').replace('&edge=curl',''):null;
    return {key:'gb:'+it.id,title:v.title+(v.subtitle&&v.subtitle.length<40?': '+v.subtitle:''),year:(v.publishedDate||'').slice(0,4),sub:(v.authors||[]).slice(0,2).join(', '),source:'Google Books',
      preview:u,imgs:u?[u.replace('zoom=1','zoom=2'),u]:[]}}).filter(r=>r.title);
}
async function bookSearch(q){
  const [a,b]=await Promise.allSettled([openLibrarySearch(q),googleBooksSearch(q)]);
  const ol=a.status==='fulfilled'?a.value:[], gb=b.status==='fulfilled'?b.value:[];
  if(a.status==='rejected'&&b.status==='rejected') throw a.reason;
  // books with a cover first; one entry per title + author
  const seen=new Map(); const out=[];
  for(const r of [...ol,...gb]){ const k=norm(r.title)+'|'+norm(r.sub.split(',')[0]||'');
    const m=seen.get(k); if(m){ if(!m.preview&&r.preview){m.preview=r.preview} m.imgs=m.imgs.concat(r.imgs); if(!m.year) m.year=r.year; continue; }
    seen.set(k,r); out.push(r); }
  return out.sort((x,y)=>(!!y.preview)-(!!x.preview)).slice(0,14);
}
async function onlineSearch(cat,q){
  if(cat==='drinks') return offSearch(q);
  if(cat==='books') return bookSearch(q);
  if(cat==='movies') return wikiSearch(q,'movie');
  if(cat==='series') return tvmazeSearch(q);
  if(cat==='games'){
    const [a,b]=await Promise.allSettled([steamSearch(q),wikiSearch(q,'game')]);
    const st=a.status==='fulfilled'?a.value:[], wk=b.status==='fulfilled'?b.value:[];
    if(a.status==='rejected'&&b.status==='rejected') throw a.reason;
    const byN=new Map(); const out=[];
    for(const r of st){byN.set(norm(r.title),r); out.push(r)}
    for(const r of wk){const m=byN.get(norm(r.title)); if(m){m.imgs=m.imgs.concat(r.imgs); if(!m.year) m.year=r.year; if(m.sub==='Steam') m.sub=r.sub} else out.push(r)}
    return out.slice(0,14);
  }
  return [];
}
let online={q:'',cat:null,state:'idle',results:[],busy:{}}; let onlineTimer; let onlineSeq=0;
function queueOnline(){
  clearTimeout(onlineTimer);
  const cat=current, q=query.trim();
  if(!cat||!CATS[cat].online||q.length<2){online={q:'',cat,state:'idle',results:[],busy:{}};return}
  if(online.q===q&&online.cat===cat&&online.state!=='error') return;
  online={q,cat,state:'loading',results:[],busy:{}};
  const seq=++onlineSeq;
  onlineTimer=setTimeout(async()=>{
    try{const r=await onlineSearch(cat,q); if(seq!==onlineSeq) return; online.results=r; online.state='done'}
    catch(e){ if(seq!==onlineSeq) return; online.state='error' }
    if(current===cat) renderOnline();
  },900);
}
function findExisting(cat,title,year){
  const n=norm(title); const items=catItems(cat);
  return items.find(it=>norm(it.t)===n && (!year||!it.y||it.y===year)) || null;
}
async function addOnline(cat,r,btn){
  const L=lists[cat];
  const ex=findExisting(cat,r.title,r.year);
  if(ex){
    if(rankedIds(cat).has(ex.id)){toast(`“${ex.t}” is already ranked`);return}
    if(inPool(cat,ex)){toast(`“${ex.t}” is already in your list`);return}
    addFromLib(cat,ex.id); return;
  }
  online.busy[r.key]=true; if(btn){btn.disabled=true;btn.textContent='Adding…'}
  let img=null; const tries=r.imgs.slice();
  for(const u of tries){try{img=await blobToPoster(await getBlob(u));break}catch(e){}}
  if(!img&&r.steamId){const h=await steamHeader(r.steamId); if(h){try{img=await blobToPoster(await getBlob(h))}catch(e){}}}
  if(!img&&r.preview){try{img=await blobToPoster(await getBlob(r.preview))}catch(e){}}
  const id='o-'+Date.now().toString(36)+Math.random().toString(36).slice(2,5);
  L.custom.push({id,t:r.title,y:r.year||''});
  if(img){covers[id]=img; saveCovers()}
  save(cat); delete online.busy[r.key];
  toast(img?`Added “${r.title}”`:`Added “${r.title}” (no cover found)`);
  renderCategory();
}

/* ---------- prefs ---------- */
function applyPrefs(){
  const r=document.documentElement;
  r.style.setProperty('--accent',prefs.accent);
  if(prefs.mode==='auto') r.removeAttribute('data-mode'); else r.setAttribute('data-mode',prefs.mode);
  r.setAttribute('data-size',prefs.size); r.setAttribute('data-titles',prefs.titles);
  if(!$('#sheet').hidden&&!Cloud.panel) renderSheet();
}
function statusHTML(){return cloudStatus();return `<span class="status ok" id="status"><i></i>${IS_APP?'Saved on this computer':'Saved in this browser'}</span>`}
function gear(){return '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>'}

/* ---------- home ---------- */
function homeArt(k){
  const a=(HOME_ART[k]||[]).slice(0,3); if(a.length>=3) return a;
  const L=lists[k]; const ids=[]; for(const t of L.tiers) ids.push(...(L.rank[t.id]||[])); ids.push(...L.custom.map(c=>c.id));
  for(const id of ids){ if(a.length>=3) break; const u=covers[id]; if(u&&!a.includes(u)) a.push(u); }
  while(a.length<3) a.push(null); return a;
}
function renderHome(){
  if(Object.keys(CATS).length===1){ openCategory(Object.keys(CATS)[0]); return; }
  current=null; selected=null; hideMovebar();
  const keys=Object.keys(CATS);
  const tiles=keys.map(k=>{
    const c=CATS[k]; const L=lists[k]; const all=catItems(k).filter(it=>inPool(k,it)||rankedIds(k).has(it.id));
    const r=rankedIds(k).size; const pct=all.length?Math.round(r/all.length*100):0;
    const topT=L.tiers.find(t=>(L.rank[t.id]||[]).length); let top='';
    if(topT){const id=L.rank[topT.id][0]; const it=catItems(k).find(i=>i.id===id); if(it) top=`<div class="top">${esc(topT.label)}: <b>${esc(it.t)}</b></div>`;}
    return `<button class="tile" data-cat="${k}" aria-label="Open ${c.label}">
      <div class="fan">${homeArt(k).map(u=>u?`<img src="${u}" alt="">`:`<div class="fan-ph"></div>`).join('')}</div>
      <h3>${c.label}</h3>
      <div class="meta"><span>${c.blurb}</span></div>
      <div class="meter"><span style="width:${pct}%"></span></div>
      <div class="meta"><span><b style="color:var(--ink)">${r}</b> of ${all.length} ranked</span><span>${pct}%</span></div>
      ${top}
    </button>`}).join('')+(TVD.kino?kinoTileHTML():'');
  $('#app').innerHTML=`<div class="bar"><h1>Tier Vault</h1><span class="spacer"></span>${statusHTML()}<button class="btn" id="openSettings" aria-label="Settings">${gear()} <span>Settings</span></button></div>
  <p class="lede">${esc(TVD.greeting)}</p>
  <div class="tiles${keys.length===2?' two':''}">${tiles}</div>`;
  inKino=false;
  $('#app').querySelectorAll('.tile').forEach(b=>b.onclick=()=>b.dataset.kino?openKino():openCategory(b.dataset.cat));
  $('#openSettings').onclick=openSheet;
}

/* ---------- category ---------- */
function openCategory(cat){
  inKino=false;
  current=cat; tab='rank'; query=''; selected=null; editTiers=false; online={q:'',cat,state:'idle',results:[],busy:{}};
  renderCategory(); window.scrollTo(0,0);
  loadPosters(cat).then(()=>{if(current===cat) renderCategory()});
}
function cardHTML(cat,it,where){
  const u=imgFor(cat,it.id); const h=hue(it.t);
  const inner=u?`<img src="${u}" alt="" loading="lazy">`:`<div class="ph" style="background:linear-gradient(150deg,hsl(${h},55%,40%),hsl(${(h+40)%360},60%,22%))">${esc(it.t)}</div>`;
  const x=where==='tier'?`<button class="x" data-act="unrank" aria-label="Back to pool" title="Back to pool">↩</button>`:where==='pool'?`<button class="x" data-act="hide" aria-label="${it.custom?'Remove':'Not seen, move to library'}" title="${it.custom?'Remove':'Not seen – move to library'}">×</button>`:'';
  const full=it.t+(it.y?` (${it.y})`:'');
  return `<div class="card${where==='lib'?' lib':''}${selected===it.id?' sel':''}" data-id="${esc(it.id)}" title="${esc(full)}" tabindex="0">${inner}${where==='lib'?'<span class="plus">+ Add</span>':''}<span class="ttl"><span>${esc(SHORT[it.t]||it.t)}</span></span>${x}${where!=='ro'&&Cloud.group?peekHTML(it.id):''}</div>`;
}
let sortables=[];
function renderCategory(){
  const cat=current; if(!cat) return; const L=lists[cat]; const C=CATS[cat];
  cloudPrep(); const G=Cloud.group, owner=!G||G.owner===Cloud.user, theirs=G&&Cloud.view==='theirs'&&Object.keys(Cloud.others).length, both=G&&Cloud.view==='both';
  if(G&&!owner) editTiers=false;
  const items=catItems(cat); const byId=Object.fromEntries(items.map(i=>[i.id,i]));
  const ranked=rankedIds(cat);
  const q=query.trim().toLowerCase(); const nq=norm(q); const match=it=>!q||it.t.toLowerCase().includes(q)||(nq&&norm(it.t).includes(nq));
  const poolItems=items.filter(it=>inPool(cat,it)&&!ranked.has(it.id));
  const libItems=items.filter(it=>!inPool(cat,it)&&!ranked.has(it.id));
  const poolShown=poolItems.filter(match), libShown=libItems.filter(match);
  const total=poolItems.length+ranked.size;
  const scrollY=window.scrollY;

  const rows=L.tiers.map((t,i)=>{
    const ids=(L.rank[t.id]||[]).filter(id=>byId[id]);
    const fg=textOn(t.color);
    const label=editTiers?`<input type="text" id="tl-${t.id}" value="${esc(t.label)}" data-tier="${t.id}" aria-label="Tier name">
      <div class="tools"><input type="color" value="${t.color}" data-color="${t.id}" aria-label="Tier color"><button data-up="${t.id}" aria-label="Move up"${i===0?' disabled':''}>↑</button><button data-down="${t.id}" aria-label="Move down"${i===L.tiers.length-1?' disabled':''}>↓</button><button data-del="${t.id}" aria-label="Delete tier">✕</button></div>`
      :`<span>${esc(t.label)}</span><span class="n">${ids.length}</span>`;
    return `<div class="row"><div class="label" style="background:${t.color};color:${fg}">${label}</div><div class="zone" data-tier="${t.id}">${ids.map(id=>cardHTML(cat,byId[id],'tier')).join('')}</div></div>`}).join('');

  let poolBody;
  if(tab==='rank'){
    poolBody=`<div class="zone${q&&!poolShown.length?' collapsed':''}" data-pool="rank">${poolShown.map(it=>cardHTML(cat,it,'pool')).join('')}</div>`;
    if(!poolShown.length){
      if(q) poolBody+=`<div class="hint">Not in your list yet.${libShown.length?` <button data-goto="lib">${libShown.length} match${libShown.length>1?'es':''} in the library</button>.`:''}</div>`;
      else if(!poolItems.length&&!ranked.size) poolBody+=`<div class="hint">This list is empty. Type a title in the search box to find it${C.online?' online':''}, or browse the library.</div>`;
      else poolBody+=`<div class="hint">Everything is ranked. Search for more ${C.noun} or open the library.</div>`;
    }
  } else {
    poolBody=`<div class="hint" style="padding-top:0">Suggestions you have not added yet. Click one to add it, or drag it straight into a tier.</div><div class="zone" data-pool="lib">${libShown.map(it=>cardHTML(cat,it,'lib')).join('')}</div>`;
    if(!libShown.length) poolBody+=`<div class="hint">${q?'No match in the library.':'The library is empty.'}</div>`;
  }

  $('#app').innerHTML=`
  <div class="bar">
    ${G?`<button class="back" id="leaveGroup" aria-label="Back to my own list" title="Back to my own list">←</button><h2>${esc(G.name)}</h2>`:Object.keys(CATS).length>1?'<button class="back" id="back" aria-label="Back to all lists">←</button><h2>'+C.label+'</h2>':'<h1 style="margin-right:6px">Tier Vault</h1><h2>'+C.label+'</h2>'}
    <span class="counts"><b>${ranked.size}</b> / ${total} ranked</span>
    <span class="spacer"></span>
    ${statusHTML()}
    <span class="actions" style="display:flex;gap:8px">
      ${cloudButtonsHTML()}
      ${owner&&!theirs?`<button class="btn${editTiers?' primary':''}" id="editTiers"><span aria-hidden="true">✎</span><span class="txt">${editTiers?'Done':'Edit tiers'}</span></button>`:''}
      ${theirs?'':`<button class="btn icon" id="exportImg" title="Save as image" aria-label="Save as image"><span aria-hidden="true">⤓</span></button>`}
      <button class="btn icon" id="openSettings" aria-label="Settings">${gear()}</button>
    </span>
  </div>
  ${G?groupStripHTML():''}
  ${theirs?othersBoardsHTML(cat):`${both?'<div class="ohead">'+avatar(Cloud.user)+'<b>You</b></div>':''}<div class="board" id="board">${rows}${editTiers?'<button class="add-tier" id="addTier">+ Add a tier</button>':''}</div>`}
  ${both?othersBoardsHTML(cat):''}
  <section class="pool"${theirs?' hidden':''}>
    <div class="pool-head">
      <div class="tabs" role="tablist">
        <button role="tab" aria-selected="${tab==='rank'}" data-tab="rank">To rank · ${q?poolShown.length:poolItems.length}</button>
        <button role="tab" aria-selected="${tab==='lib'}" data-tab="lib">Library · ${q?libShown.length:libItems.length}</button>
      </div>
      <label class="search"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg><input id="q" type="search" placeholder="${C.online?`Search or add any ${C.label.toLowerCase().replace(/s$/,'')}…`:'Search…'}" value="${esc(query)}" autocomplete="off" spellcheck="false"></label>
      <button class="btn" id="toggleCustom">+ Your own</button>
    </div>
    <form class="custom" id="customForm">
      <input type="text" id="customTitle" placeholder="Title" maxlength="80" required>
      <label class="file"><input type="file" id="customFile" accept="image/*">Add cover image</label>
      <img class="prev" id="customPrev" alt="" hidden>
      <button class="btn primary" type="submit">Add</button>
    </form>
    ${poolBody}
    <div id="online"></div>
  </section>`;
  bindCategory(cat);
  bindCloud();
  renderOnline();
  window.scrollTo(0,scrollY);
}
function renderOnline(){
  const box=$('#online'); if(!box) return; const C=CATS[current];
  if(!C.online||online.state==='idle'||online.cat!==current||online.q!==query.trim()){box.innerHTML='';return}
  let body='';
  if(online.state==='loading') body='<div class="hint"><span class="spin"></span> Searching '+esc(C.online)+'…</div>';
  else if(online.state==='error') body='<div class="hint">Online search is not reachable. Check the internet connection and try again.</div>';
  else if(!online.results.length) body='<div class="hint">Nothing found online. Try the brand and flavour, like “monster mango”, or add it with “+ Your own”.</div>';
  else body='<div class="results">'+online.results.map((r,i)=>{
    const ex=findExisting(current,r.title,r.year); const state=ex?(rankedIds(current).has(ex.id)?'Ranked':inPool(current,ex)?'In your list':'In library'):'';
    const img=r.preview?`<img src="${esc(r.preview)}" alt="" loading="lazy" referrerpolicy="no-referrer">`:`<div class="ph" style="background:hsl(${hue(r.title)},45%,32%)">${esc(r.title)}</div>`;
    return `<div class="res"><div class="rimg">${img}</div><div class="rtxt"><b>${esc(r.title)}</b><span>${esc([r.year,r.sub].filter(Boolean).join(' · '))}</span><small>${esc(r.source)}</small></div>
      <button class="btn${state&&state!=='In library'?'':' primary'}" data-add="${i}"${online.busy[r.key]?' disabled':''}>${online.busy[r.key]?'Adding…':state==='Ranked'||state==='In your list'?state:'+ Add'}</button></div>`}).join('')+'</div>';
  box.innerHTML=`<h4 class="online-h">Online · ${esc(C.online)}</h4>${body}`;
  box.querySelectorAll('[data-add]').forEach(b=>b.onclick=()=>{const r=online.results[+b.dataset.add]; addOnline(current,r,b)});
}
function bindCategory(cat){
  const L=lists[cat];
  const bk=$('#back'); if(bk) bk.onclick=renderHome;
  $('#openSettings').onclick=openSheet;
  if($('#editTiers')) $('#editTiers').onclick=()=>{editTiers=!editTiers;renderCategory()};
  const ex=$('#exportImg'); if(ex) ex.onclick=()=>exportImage(cat);
  $('#app').querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{tab=b.dataset.tab;selected=null;hideMovebar();renderCategory()});
  $('#app').querySelectorAll('[data-goto]').forEach(b=>b.onclick=()=>{tab='lib';renderCategory()});
  const qi=$('#q'); qi.oninput=()=>{query=qi.value;const pos=qi.selectionStart;queueOnline();renderCategory();const n=$('#q');n.focus();try{n.setSelectionRange(pos,pos)}catch(e){}};
  qi.onkeydown=e=>{if(e.key==='Escape'&&query){query='';queueOnline();renderCategory();$('#q').focus()}};
  const tc=$('#toggleCustom'); const form=$('#customForm'); let customImg=null;
  tc.onclick=()=>{form.classList.toggle('open'); if(form.classList.contains('open')){$('#customTitle').value=query;$('#customTitle').focus()}};
  $('#customFile').onchange=async e=>{const f=e.target.files[0]; if(!f) return; try{customImg=await blobToPoster(f); const p=$('#customPrev'); p.src=customImg; p.hidden=false}catch(err){toast('That image could not be read. Try a JPG or PNG.')}};
  form.onsubmit=e=>{e.preventDefault(); const t=$('#customTitle').value.trim(); if(!t) return;
    const ex=findExisting(cat,t,''); if(ex){toast(`“${ex.t}” already exists`); return}
    const id='c-'+Date.now().toString(36); L.custom.push({id,t,y:''}); if(customImg){covers[id]=customImg; saveCovers()}
    save(cat); query=''; tab='rank'; queueOnline(); renderCategory(); toast(`Added “${t}”`)};
  if(editTiers){
    $('#app').querySelectorAll('input[data-tier]').forEach(inp=>inp.onchange=()=>{const t=L.tiers.find(x=>x.id===inp.dataset.tier); t.label=inp.value.trim()||t.label; save(cat)});
    $('#app').querySelectorAll('input[data-color]').forEach(inp=>{inp.oninput=()=>{const t=L.tiers.find(x=>x.id===inp.dataset.color); t.color=inp.value; const lab=inp.closest('.label'); lab.style.background=t.color; lab.style.color=textOn(t.color)}; inp.onchange=()=>save(cat)});
    $('#app').querySelectorAll('[data-up],[data-down]').forEach(b=>b.onclick=()=>{const id=b.dataset.up||b.dataset.down; const i=L.tiers.findIndex(t=>t.id===id); const j=b.dataset.up?i-1:i+1; if(j<0||j>=L.tiers.length) return; [L.tiers[i],L.tiers[j]]=[L.tiers[j],L.tiers[i]]; save(cat); renderCategory()});
    $('#app').querySelectorAll('[data-del]').forEach(b=>b.onclick=()=>{ if(L.tiers.length<=1){toast('Keep at least one tier.');return}
      if(b.dataset.armed!=='1'){b.dataset.armed='1';b.textContent='?';b.title='Click again to delete';setTimeout(()=>{b.dataset.armed='';b.textContent='✕'},2500);return}
      const id=b.dataset.del; delete L.rank[id]; L.tiers=L.tiers.filter(t=>t.id!==id); save(cat); renderCategory()});
    $('#addTier').onclick=()=>{L.tiers.push({id:'t'+Date.now().toString(36),label:'New tier',color:'#8a8fa0'}); save(cat); renderCategory()};
  }
  $('#app').querySelectorAll('.card').forEach(el=>{ if(el.closest('[data-ro]')) return;
    el.addEventListener('click',e=>{ const id=el.dataset.id; const act=e.target.closest('[data-act]');
      if(act){e.stopPropagation(); if(act.dataset.act==='unrank') unrank(cat,id); else hideItem(cat,id); return}
      if(el.classList.contains('lib')){addFromLib(cat,id);return}
      selected=selected===id?null:id; document.querySelectorAll('.card.sel').forEach(c=>c.classList.remove('sel')); if(selected) el.classList.add('sel'); showMovebar(cat);
    });
    el.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();el.click()}});
  });
  setupSortable(cat);
  showMovebar(cat);
}
function setupSortable(cat){
  sortables.forEach(s=>{try{s.destroy()}catch(e){}}); sortables=[];
  if(editTiers||!window.Sortable) return;
  document.querySelectorAll('#app .zone:not([data-ro])').forEach(z=>{
    sortables.push(Sortable.create(z,{group:{name:'vault',pull:true,put:true},animation:150,ghostClass:'ghost',chosenClass:'chosen',delay:180,delayOnTouchOnly:true,touchStartThreshold:4,filter:'.x',preventOnFilter:false,scroll:true,bubbleScroll:true,
      onStart:()=>{dragging=true;selected=null;hideMovebar()},
      onEnd:()=>{dragging=false;syncFromDom(cat)}}));
  });
}
function syncFromDom(cat){
  const L=lists[cat]; const rank={};
  document.querySelectorAll('#board .zone').forEach(z=>{rank[z.dataset.tier]=[...z.querySelectorAll('.card')].map(c=>c.dataset.id)});
  const rankedNow=new Set(Object.values(rank).flat());
  const lib=document.querySelector('.zone[data-pool="lib"]'); const libIds=lib?[...lib.querySelectorAll('.card')].map(c=>c.dataset.id):[];
  const pool=document.querySelector('.zone[data-pool="rank"]'); const poolIds=pool?[...pool.querySelectorAll('.card')].map(c=>c.dataset.id):[];
  const items=Object.fromEntries(catItems(cat).map(i=>[i.id,i]));
  for(const id of [...rankedNow,...poolIds]){ if(items[id]&&items[id].x&&!L.added.includes(id)) L.added.push(id); L.hidden=L.hidden.filter(h=>h!==id); }
  for(const id of libIds){ const it=items[id]; if(it&&inPool(cat,it)){ L.added=L.added.filter(a=>a!==id); if(!it.x&&!it.custom&&!L.hidden.includes(id)) L.hidden.push(id);} }
  L.rank=rank; save(cat); renderCategory();
}
function moveTo(cat,id,tierId){const L=lists[cat]; for(const t of L.tiers) L.rank[t.id]=(L.rank[t.id]||[]).filter(x=>x!==id); (L.rank[tierId]=L.rank[tierId]||[]).push(id);
  const it=catItems(cat).find(i=>i.id===id); if(it&&it.x&&!L.added.includes(id)) L.added.push(id); L.hidden=L.hidden.filter(h=>h!==id); save(cat)}
function unrank(cat,id){const L=lists[cat]; for(const t of L.tiers) L.rank[t.id]=(L.rank[t.id]||[]).filter(x=>x!==id); selected=null; save(cat); renderCategory()}
function hideItem(cat,id){const L=lists[cat]; const it=catItems(cat).find(i=>i.id===id); if(!it) return;
  if(it.custom){L.custom=L.custom.filter(c=>c.id!==id); delete covers[id]; saveCovers(); toast(`Removed “${it.t}”`)} else { if(it.x) L.added=L.added.filter(a=>a!==id); else if(!L.hidden.includes(id)) L.hidden.push(id); toast(`Moved “${it.t}” to the library`)}
  for(const t of L.tiers) L.rank[t.id]=(L.rank[t.id]||[]).filter(x=>x!==id);
  selected=null; save(cat); renderCategory()}
function addFromLib(cat,id){const L=lists[cat]; const it=catItems(cat).find(i=>i.id===id); if(!it) return; if(it.x&&!L.added.includes(id)) L.added.push(id); L.hidden=L.hidden.filter(h=>h!==id); save(cat); renderCategory(); toast(`Added “${it.t}” to your list`)}

/* move bar */
function showMovebar(cat){
  const mb=$('#movebar'); if(!selected){mb.hidden=true;return}
  const L=lists[cat]; const it=catItems(cat).find(i=>i.id===selected); if(!it){mb.hidden=true;return}
  const cur=L.tiers.find(t=>(L.rank[t.id]||[]).includes(selected));
  $('#movebarIn').innerHTML=`<span class="what">${esc(it.t)}</span>`+L.tiers.map(t=>`<button class="tb" data-to="${t.id}" style="background:${t.color};color:${textOn(t.color)}${cur&&cur.id===t.id?';outline:2px solid var(--ink)':''}">${esc(t.label)}</button>`).join('')+
    (cur?`<button class="btn" data-to="__pool">Back to pool</button>`:`<button class="btn" data-to="__hide">${it.custom?'Remove':'Not seen'}</button>`)+`<button class="btn" data-to="__cover">Change cover</button><button class="btn ghost" data-to="__x">Cancel</button>`;
  mb.hidden=false;
  mb.querySelectorAll('[data-to]').forEach(b=>b.onclick=()=>{const to=b.dataset.to; const id=selected;
    if(to==='__x'){selected=null;hideMovebar();document.querySelectorAll('.card.sel').forEach(c=>c.classList.remove('sel'));return}
    if(to==='__pool'){unrank(cat,id);hideMovebar();return}
    if(to==='__hide'){hideItem(cat,id);hideMovebar();return}
    if(to==='__cover'){pickCover(cat,id);return}
    moveTo(cat,id,to); selected=null; hideMovebar(); renderCategory();});
}
function pickCover(cat,id){
  const inp=document.createElement('input'); inp.type='file'; inp.accept='image/*';
  inp.onchange=async()=>{const f=inp.files[0]; if(!f) return; try{covers[id]=await blobToPoster(f); saveCovers(); selected=null; hideMovebar(); renderCategory(); toast('Cover updated')}catch(e){toast('That image could not be read. Try a JPG or PNG.')}};
  inp.click();
}
function hideMovebar(){$('#movebar').hidden=true}
document.addEventListener('keydown',e=>{if(e.key==='Escape'){if(!$('#sheet').hidden){closeSheet();return} if(selected){selected=null;hideMovebar();document.querySelectorAll('.card.sel').forEach(c=>c.classList.remove('sel'))}}});

/* save tier list as picture */
function loadImg(src){return new Promise(r=>{const i=new Image();i.onload=()=>r(i);i.onerror=()=>r(null);i.src=src})}
async function exportImage(cat){
  await loadPosters(cat); try{await document.fonts.ready}catch(e){}
  const L=lists[cat]; const items=Object.fromEntries(catItems(cat).map(i=>[i.id,i]));
  const W=1400, lab=190, pw=96, ph=144, gap=6, pad=16, perRow=Math.floor((W-lab-pad*2)/(pw+gap));
  const rows=L.tiers.map(t=>({t,ids:(L.rank[t.id]||[]).filter(id=>items[id])}));
  const heights=rows.map(r=>Math.max(1,Math.ceil(r.ids.length/perRow))*(ph+gap)+gap);
  const head=90, H=head+heights.reduce((a,b)=>a+b,0)+pad*2+30;
  const c=document.createElement('canvas'); c.width=W; c.height=H; const x=c.getContext('2d');
  x.fillStyle='#101218'; x.fillRect(0,0,W,H);
  x.fillStyle='#ffffff'; x.font='900 56px "Big Shoulders Display", Impact, sans-serif'; x.fillText(Cloud.group?Cloud.group.name.toUpperCase()+' · '+(Cloud.user||'').toUpperCase():`MY ${CATS[cat].label.toUpperCase()} TIER LIST`,pad+4,68);
  let y=head;
  for(let i=0;i<rows.length;i++){const {t,ids}=rows[i]; const h=heights[i];
    x.fillStyle=t.color; x.fillRect(pad,y,lab,h-2); x.fillStyle=textOn(t.color); x.font='800 26px "Big Shoulders Display", Impact, sans-serif'; x.textAlign='center';
    const words=t.label.toUpperCase().split(' '); const lines=[]; let line=''; for(const w of words){const tst=line?line+' '+w:w; if(x.measureText(tst).width>lab-20&&line){lines.push(line);line=w}else line=tst} lines.push(line);
    lines.forEach((l,k)=>x.fillText(l,pad+lab/2,y+h/2-(lines.length-1)*14+k*28+9)); x.textAlign='left';
    x.fillStyle='#181b22'; x.fillRect(pad+lab,y,W-pad*2-lab,h-2);
    for(let k=0;k<ids.length;k++){const it=items[ids[k]]; const px=pad+lab+gap+(k%perRow)*(pw+gap), py=y+gap+Math.floor(k/perRow)*(ph+gap);
      const src=imgFor(cat,it.id); const im=src?await loadImg(src):null;
      if(im){const s=Math.max(pw/im.width,ph/im.height); x.save(); x.beginPath(); x.rect(px,py,pw,ph); x.clip(); x.drawImage(im,px+(pw-im.width*s)/2,py+(ph-im.height*s)/2,im.width*s,im.height*s); x.restore()}
      else {x.fillStyle=`hsl(${hue(it.t)},50%,35%)`; x.fillRect(px,py,pw,ph); x.fillStyle='#fff'; x.font='700 13px Figtree, sans-serif'; x.fillText(it.t.slice(0,14),px+6,py+ph/2)}}
    y+=h;}
  x.fillStyle='#8a90a0'; x.font='500 16px Figtree, sans-serif'; x.fillText('Made with Tier Vault',pad+4,H-18);
  const blob=await new Promise(r=>c.toBlob(r,'image/png'));
  if(!IS_APP){const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`${cat}-tier-list.png`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),4000);toast('Image downloaded');return}
  try{
    let dir=''; try{dir=(await Neutralino.os.getPath('pictures')).replace(/[\\/]+$/,'')+'/'}catch(e){}
    let path=await Neutralino.os.showSaveDialog('Save tier list image',{defaultPath:dir+`${cat}-tier-list.png`,filters:[{name:'PNG image',extensions:['png']}]});
    if(!path) return; if(!/\.png$/i.test(path)) path+='.png';
    await Neutralino.filesystem.writeBinaryFile(path,await blob.arrayBuffer()); toast('Image saved');
  }catch(e){toast('The image could not be saved.')}
}

/* ---------- settings ---------- */
function openSheet(){Cloud.panel=null;$('#sheet').classList.remove('center');renderSheet(); $('#sheet').hidden=false; $('#sheet').onclick=e=>{if(e.target.id==='sheet') closeSheet()}}
function closeSheet(){$('#sheet').hidden=true;$('#sheet').classList.remove('center');Cloud.panel=null}
async function copyText(t){ if(IS_APP){try{await Neutralino.clipboard.writeText(t);return true}catch(e){}} try{await navigator.clipboard.writeText(t);return true}catch(e){return false} }
function renderSheet(){
  const cat=current;
  $('#sheet').innerHTML=`<div class="panel" role="dialog" aria-label="Settings">
    <div style="display:flex;align-items:center;justify-content:space-between"><h3>Settings</h3><button class="btn" id="closeSheet">Close</button></div>
    <div><h4>Accent color</h4><div class="swatches">${ACCENTS.map(a=>`<button style="background:${a}" data-accent="${a}" aria-label="Accent ${a}" aria-pressed="${prefs.accent===a}"></button>`).join('')}<input type="color" id="accentCustom" value="${prefs.accent}" aria-label="Custom accent color"></div></div>
    <div><h4>Theme</h4><div class="seg">${[['auto','Auto'],['light','Light'],['dark','Dark']].map(([k,l])=>`<button data-mode="${k}" aria-pressed="${prefs.mode===k}">${l}</button>`).join('')}</div></div>
    <div><h4>Poster size</h4><div class="seg">${[['s','Small'],['m','Medium'],['l','Large']].map(([k,l])=>`<button data-size="${k}" aria-pressed="${prefs.size===k}">${l}</button>`).join('')}</div></div>
    <div><h4>Titles on posters</h4><div class="seg">${[['on','Show'],['off','Hide']].map(([k,l])=>`<button data-titles="${k}" aria-pressed="${prefs.titles===k}">${l}</button>`).join('')}</div></div>
    <div><h4>Account</h4><div class="stack">${Cloud.user?`<span class="small">Logged in as <b>${esc(Cloud.user)}</b>. Your list is saved to your account.</span><button class="btn" id="sLogout">Log out</button>`:`<span class="small">You are a guest, so your list only lives in this browser.</span><button class="btn primary" id="sLogin">Log in or create account</button>`}</div></div>
    ${cat?`<div><h4>${Cloud.group?'Your list in this group':CATS[cat].label+' list'}</h4><div class="stack">
      ${!Cloud.group||Cloud.group.owner===Cloud.user?'<button class="btn" id="resetTiers">Restore default tier names and colors</button>':''}
      <button class="btn danger" id="clearRank">Move everything back to the pool</button>
      <span class="small">Tier names and colors can also be changed with “Edit tiers”.</span></div></div>`:''}
    <div><h4>Backup</h4><div class="stack">
      <span class="small">A backup code copies your rankings somewhere else, for example into the desktop app.</span>
      <button class="btn" id="copyBackup">Copy backup code</button>
      <textarea id="restoreBox" placeholder="Paste a backup code here to restore it"></textarea>
      <button class="btn" id="restore">Restore from backup</button>
    </div></div>
  </div>`;
  const P=$('#sheet');
  $('#closeSheet').onclick=closeSheet;
  if($('#sLogout')) $('#sLogout').onclick=logout; if($('#sLogin')) $('#sLogin').onclick=()=>welcome();
  P.querySelectorAll('[data-accent]').forEach(b=>b.onclick=()=>{prefs.accent=b.dataset.accent;applyPrefs();savePrefs()});
  $('#accentCustom').onchange=e=>{prefs.accent=e.target.value;applyPrefs();savePrefs()};
  P.querySelectorAll('.seg [data-mode]').forEach(b=>b.onclick=()=>{prefs.mode=b.dataset.mode;applyPrefs();savePrefs()});
  P.querySelectorAll('.seg [data-size]').forEach(b=>b.onclick=()=>{prefs.size=b.dataset.size;applyPrefs();savePrefs()});
  P.querySelectorAll('.seg [data-titles]').forEach(b=>b.onclick=()=>{prefs.titles=b.dataset.titles;applyPrefs();savePrefs()});
  const rt=$('#resetTiers'); if(rt) rt.onclick=()=>arm(rt,'Click again to restore the defaults',()=>{const L=lists[cat]; const f=freshList(cat); const old=L.tiers; const rank={};
      f.tiers.forEach((t,i)=>{rank[t.id]=old[i]?(L.rank[old[i].id]||[]):[]}); L.tiers=f.tiers; L.rank=rank; save(cat); renderCategory(); renderSheet(); toast('Default tiers restored')});
  const cr=$('#clearRank'); if(cr) cr.onclick=()=>arm(cr,'Click again to clear all rankings',()=>{lists[cat].rank={}; save(cat); renderCategory(); renderSheet(); toast('All posters are back in the pool')});
  $('#copyBackup').onclick=async()=>{const data=JSON.stringify(Object.assign(personalData(),{covers}));
    if(await copyText(data)) toast('Backup copied'); else {const ta=$('#restoreBox'); ta.value=data; ta.select(); toast('Select all and copy the code')}};
  $('#restore').onclick=()=>{try{const d=JSON.parse($('#restoreBox').value); if(!d||!d.lists) throw 0;
      for(const c of Object.keys(CATS)) if(d.lists[c]){lists[c]=normList(c,d.lists[c]); lists[c].updated=Date.now()}
      if(d.covers&&typeof d.covers==='object'){Object.assign(covers,d.covers); saveCovers()}
      if(d.kino) kino=normKino(d.kino);
      if(d.prefs){prefs=Object.assign({},DEFAULT_PREFS,d.prefs); applyPrefs()}
      save(null); closeSheet(); current?renderCategory():inKino?renderKino():renderHome(); toast('Backup restored')}catch(e){toast('That code is not a valid backup.')}};
}
function arm(btn,msg,fn){if(btn.dataset.armed==='1'){fn();return} const old=btn.textContent; btn.dataset.armed='1'; btn.textContent=msg; setTimeout(()=>{btn.dataset.armed='';btn.textContent=old},3000)}

/* ---------- boot ---------- */
(async function boot(){
  await Store.init(); await Cloud.init();
  let data=await Store.read('data');
  if(!data||!data.lists){ data=JSON.parse(JSON.stringify(TVD.seed)); await Store.write('data',data).catch(()=>{}); }
  prefs=Object.assign({},DEFAULT_PREFS,data.prefs||{});
  for(const c of Object.keys(CATS)) lists[c]=normList(c,data.lists[c]);
  covers=(await Store.read('covers'))||{};
  if(typeof drinksMigrate==='function') await drinksMigrate();
  kino=normKino(data.kino);
  if(TVD.kino){ kinoCache=await Store.read('kino-cache'); }
  applyPrefs();
  try{ await Promise.race([Promise.all([document.fonts.load('800 40px "Big Shoulders Display"'),document.fonts.load('700 13px Figtree')]), new Promise(r=>setTimeout(r,1500))]); }catch(e){}
  renderHome();
  if(IS_APP){
    Neutralino.events.on('windowClose',async()=>{try{await flushAll()}catch(e){} Neutralino.app.exit()});
  }
  Object.keys(CATS).forEach(c=>setTimeout(()=>loadPosters(c),800));
  if(TVD.kino) setTimeout(()=>refreshKino(false),300);
  if(typeof startAutoCovers==='function') setTimeout(startAutoCovers,1500);
  Cloud.afterBoot();
})();
