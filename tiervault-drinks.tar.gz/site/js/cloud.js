/* Tier Vault – accounts, group lists and live sync. Loaded before app.js; uses its helpers at call time. */
const Cloud = {
  token: lsGet('tv_token'), user: lsGet('tv_user'),
  cache: { data: null, covers: null }, groups: [], invites: [], down: false,
  group: null, gv: 0, others: {}, foreignCov: {}, priv: false, personal: null,
  view: lsGet('tv_view') || 'peek', hide: new Set(), panel: null, peek: {}
};
function lsGet(k){ try{ return localStorage.getItem(k); }catch(e){ return null; } }
function lsSet(k,v){ try{ v==null ? localStorage.removeItem(k) : localStorage.setItem(k,v); }catch(e){} }

async function api(a, opt = {}){
  const q = opt.q ? '&' + new URLSearchParams(opt.q) : '';
  const h = {}; if(opt.body) h['Content-Type'] = 'application/json'; if(Cloud.token) h.Authorization = 'Bearer ' + Cloud.token;
  let r; try{ r = await fetch('/api?a=' + a + q, { method: opt.body ? 'POST' : 'GET', headers: h, body: opt.body ? JSON.stringify(opt.body) : undefined }); }
  catch(e){ throw new Error('No connection. Check your internet.'); }
  let j = {}; try{ j = await r.json(); }catch(e){}
  if(r.status === 401 && Cloud.token && a !== 'login'){ logout(); }
  if(!r.ok){ const e = new Error(j.error || 'Something went wrong.'); e.status = r.status; throw e; }
  return j;
}

/* ---------- boot / account ---------- */
Cloud.init = async function(){
  if(!Cloud.token) return;
  try{
    const me = await api('me');
    Cloud.cache.data = me.data; Cloud.cache.covers = me.covers; Cloud.groups = me.groups; Cloud.invites = me.invites;
  }catch(e){
    if(!Cloud.token) return;                 // was logged out (401)
    Cloud.down = true; Cloud.user = null;     // server unreachable: work locally for now
    setTimeout(()=>toast('Could not reach the server, saving in this browser for now.'), 800);
  }
};
Cloud.save = function(what, obj){ return api('save', { body: { what, obj } }); };

async function doAuth(kind, u, p){
  const r = await api(kind, { body: { u, p } });
  Cloud.token = r.token; Cloud.user = r.u; lsSet('tv_token', r.token); lsSet('tv_user', r.u); lsSet('tv_seen', '1');
  // first login on this browser: take the guest rankings along
  const me = await api('me');
  const guest = (()=>{ try{ return JSON.parse(localStorage.getItem('tv_' + TVD.variant + '_data')); }catch(e){ return null; } })();
  const guestCov = (()=>{ try{ return JSON.parse(localStorage.getItem('tv_' + TVD.variant + '_covers')); }catch(e){ return null; } })();
  const hasRanks = d => d && d.lists && Object.values(d.lists).some(l => l && l.rank && Object.values(l.rank).some(a => a.length));
  if(!hasRanks(me.data) && hasRanks(guest)){
    await Cloud.save('data', guest); if(guestCov) await Cloud.save('covers', guestCov);
  }
  location.reload();
}
function logout(){
  lsSet('tv_token', null); lsSet('tv_user', null); Cloud.token = Cloud.user = null; location.href = location.pathname;
}

function authFormHTML(msg){
  return `<form class="auth" id="authForm" autocomplete="on">
    ${msg ? `<p class="small" style="margin:0">${msg}</p>` : ''}
    <input id="au" name="username" placeholder="Username" autocomplete="username" autocapitalize="none" spellcheck="false" maxlength="20" required>
    <input id="ap" name="password" type="password" placeholder="Password" autocomplete="current-password" required>
    <div class="row2"><button class="btn primary" type="submit" data-kind="login">Log in</button><button class="btn" type="submit" data-kind="register">Create account</button></div>
    <span class="small err" id="aerr"></span>
  </form>`;
}
function bindAuth(){
  const f = $('#authForm'); if(!f) return; let kind = 'login';
  f.querySelectorAll('[data-kind]').forEach(b => b.onclick = () => kind = b.dataset.kind);
  f.onsubmit = async e => { e.preventDefault(); const err = $('#aerr'); err.textContent = '';
    f.querySelectorAll('button').forEach(b => b.disabled = true);
    try{ await doAuth(kind, $('#au').value.trim(), $('#ap').value); }
    catch(x){ err.textContent = x.message; f.querySelectorAll('button').forEach(b => b.disabled = false); } };
}

/* ---------- panels ---------- */
function openPanel(name, html, center){
  Cloud.panel = name; const s = $('#sheet');
  s.classList.toggle('center', !!center);
  s.innerHTML = `<div class="panel" role="dialog">${html}</div>`; s.hidden = false;
  s.onclick = e => { if(e.target.id === 'sheet') closeSheet(); };
  s.querySelectorAll('[data-close]').forEach(b => b.onclick = closeSheet);
  bindAuth();
}
function welcome(msg){
  openPanel('welcome', `<h3>Tier Vault</h3>
    ${authFormHTML(msg || 'Log in to save your list everywhere and rank together with friends. Just a username and a password.')}
    <button class="btn ghost" data-close>Continue as guest</button>`, true);
  $('#sheet .btn.ghost').onclick = () => { lsSet('tv_seen', '1'); closeSheet(); };
}

/* ---------- groups panel ---------- */
function openGroups(){
  const cat = Object.keys(CATS)[0];
  if(!Cloud.user){ openPanel('groups', `<div class="phead"><h3>Group lists</h3><button class="btn" data-close>Close</button></div>
      ${authFormHTML('Rank together with friends: everyone gets their own list in the group and you can peek at each other. Log in or create an account first, it only takes a username.')}`); return; }
  const row = g => `<div class="grow"><div><b>${esc(g.name)}</b><span class="small">by ${esc(g.owner)} · code ${g.code}</span></div>`;
  openPanel('groups', `<div class="phead"><h3>Group lists</h3><button class="btn" data-close>Close</button></div>
    ${Cloud.invites.length ? `<div><h4>Invitations</h4>${Cloud.invites.map(g => row(g) + `<span class="gbtns"><button class="btn primary" data-join="${g.code}">Join</button><button class="btn" data-decline="${g.code}">✕</button></span></div>`).join('')}</div>` : ''}
    <div><h4>Your groups</h4>${Cloud.groups.length ? Cloud.groups.map(g => row(g) + `<button class="btn${Cloud.group && Cloud.group.code === g.code ? '' : ' primary'}" data-open="${g.code}">${Cloud.group && Cloud.group.code === g.code ? 'Open now' : 'Open'}</button></div>`).join('') : '<p class="small" style="margin:0">None yet. Start one and invite your friends.</p>'}</div>
    <form class="gform" id="gCreate"><h4>New group list</h4><div class="row2"><input id="gName" placeholder="Name, e.g. Energy drink night" maxlength="40"><button class="btn primary" type="submit">Create</button></div></form>
    <form class="gform" id="gJoin"><h4>Got a code?</h4><div class="row2"><input id="gCode" placeholder="ABC123" maxlength="6" autocapitalize="characters" spellcheck="false" style="text-transform:uppercase;letter-spacing:.15em"><button class="btn" type="submit">Join</button></div></form>
    <div class="small">Logged in as <b>${esc(Cloud.user)}</b> · <button class="linkbtn" id="gLogout">Log out</button></div>`);
  const P = $('#sheet');
  P.querySelectorAll('[data-open]').forEach(b => b.onclick = () => { closeSheet(); openGroup(b.dataset.open); });
  P.querySelectorAll('[data-join]').forEach(b => b.onclick = () => joinGroup(b.dataset.join));
  P.querySelectorAll('[data-decline]').forEach(b => b.onclick = async () => { await api('gdecline', { body: { code: b.dataset.decline } }).catch(()=>{}); Cloud.invites = Cloud.invites.filter(g => g.code !== b.dataset.decline); openGroups(); refreshBar(); });
  $('#gCreate').onsubmit = async e => { e.preventDefault();
    const src = (Cloud.personal || lists[cat]);
    try{ const g = await api('gcreate', { body: { name: $('#gName').value, tiers: src.tiers } }); Cloud.groups.push({ code: g.room.code, name: g.room.name, owner: g.room.owner }); closeSheet(); enterGroup(g); openInvite(); }
    catch(x){ toast(x.message); } };
  $('#gJoin').onsubmit = e => { e.preventDefault(); const c = $('#gCode').value.trim(); if(c) joinGroup(c); };
  $('#gLogout').onclick = logout;
}
async function joinGroup(code){
  try{ const g = await api('gjoin', { body: { code } });
    if(!Cloud.groups.some(x => x.code === g.room.code)) Cloud.groups.push({ code: g.room.code, name: g.room.name, owner: g.room.owner });
    Cloud.invites = Cloud.invites.filter(x => x.code !== g.room.code);
    closeSheet(); enterGroup(g); toast(`You joined “${g.room.name}”`);
  }catch(x){ toast(x.message); }
}
async function openGroup(code){
  try{ enterGroup(await api('gget', { q: { code } })); }
  catch(x){ toast(x.message); if(x.status === 403 || x.status === 404){ Cloud.groups = Cloud.groups.filter(g => g.code !== code); history.replaceState(null, '', location.pathname); } }
}

/* ---------- entering / leaving a group ---------- */
function enterGroup(g){
  const cat = Object.keys(CATS)[0];
  if(!Cloud.group) Cloud.personal = lists[cat];
  Cloud.group = null; Cloud.hide = new Set();
  applyGroup(g, true);
  history.replaceState(null, '', '?g=' + g.room.code);
  selected = null; hideMovebar(); query = ''; tab = 'rank'; editTiers = false;
  if(current !== cat) openCategory(cat); else renderCategory();
  window.scrollTo(0, 0); startPoll();
}
function leaveGroupView(){
  stopPoll(); const cat = Object.keys(CATS)[0];
  lists[cat] = Cloud.personal; Cloud.personal = null; Cloud.group = null; Cloud.others = {}; Cloud.foreignCov = {};
  history.replaceState(null, '', location.pathname);
  selected = null; hideMovebar(); editTiers = false; renderCategory(); window.scrollTo(0, 0);
}
function applyGroup(g, initial){
  const cat = Object.keys(CATS)[0], me = Cloud.user;
  const old = Cloud.group; Cloud.group = g.room; Cloud.gv = g.v;
  Cloud.others = {}; Cloud.foreignCov = {};
  for(const [u, e] of Object.entries(g.lists)){ if(u === me) continue; Cloud.others[u] = e; if(e.cov) Object.assign(Cloud.foreignCov, e.cov); }
  const tiers = g.room.tiers && g.room.tiers.length ? g.room.tiers : null;
  if(initial){
    const mine = (g.lists[me] && g.lists[me].list) || null;
    Cloud.priv = !!(mine && mine.private);
    lists[cat] = normList(cat, mine ? Object.assign({}, mine, tiers ? { tiers } : {}) : (tiers ? { tiers, rank: {} } : null));
    if(mine && mine.cov) Object.assign(covers, mine.cov);
  } else if(tiers && g.room.owner !== me && JSON.stringify(tiers) !== JSON.stringify(lists[cat].tiers)){
    lists[cat] = normList(cat, Object.assign({}, lists[cat], { tiers }));   // the owner changed the tiers
  }
  return !old || JSON.stringify(old) !== JSON.stringify(g.room);
}
function saveGroupList(cat){
  schedule('group', async () => {
    if(!Cloud.group) return;
    const L = lists[cat], cov = {};
    for(const c of L.custom) if(covers[c.id]) cov[c.id] = covers[c.id];
    const body = { code: Cloud.group.code, list: Object.assign({}, L, { private: Cloud.priv ? 1 : 0 }), cov };
    if(Cloud.group.owner === Cloud.user){ body.tiers = L.tiers; Cloud.group.tiers = L.tiers; }
    const r = await api('gsave', { body });
    if(r.v === Cloud.gv + 1) Cloud.gv = r.v;      // only our own change happened: no need to reload
  }, 500);
}

/* ---------- live updates: only while a group is open and the tab is visible ---------- */
let pollT = null, idle = 0;
function stopPoll(){ clearTimeout(pollT); pollT = null; }
function startPoll(){
  stopPoll(); idle = 0;
  const tick = async () => {
    if(!Cloud.group || document.hidden) return;
    const code = Cloud.group.code;
    try{
      const r = await api('gpoll', { q: { code, v: Cloud.gv } });
      if(!Cloud.group || Cloud.group.code !== code) return;
      if(r.same) idle++;
      else { idle = 0; const roomChanged = applyGroup(r, false); if(!dragging && (Cloud.view !== 'mine' || roomChanged)) rerenderKeepFocus(); }
    }catch(x){ if(x.status === 403 || x.status === 404){ toast(x.message); leaveGroupView(); return; } idle++; }
    // fast while things happen, slower when quiet or when you only look at your own list
    const base = Cloud.view === 'mine' ? 20000 : 4000;
    pollT = setTimeout(tick, idle > 15 ? Math.max(base, 15000) : base);
  };
  pollT = setTimeout(tick, 3000);
}
document.addEventListener('visibilitychange', () => { if(document.hidden) stopPoll(); else if(Cloud.group) startPoll(); });
function rerenderKeepFocus(){
  const a = document.activeElement, isQ = a && a.id === 'q', pos = isQ ? a.selectionStart : 0;
  if(!$('#sheet').hidden && Cloud.panel === 'invite') renderInvite();
  renderCategory();
  if(isQ){ const n = $('#q'); n.focus(); try{ n.setSelectionRange(pos, pos); }catch(e){} }
}
function refreshBar(){ if(current) rerenderKeepFocus(); }

/* ---------- invite / group settings panel ---------- */
function openInvite(){ Cloud.panel = 'invite'; renderInvite(); }
function renderInvite(){
  const g = Cloud.group; if(!g) return;
  const link = location.origin + location.pathname + '?join=' + g.code;
  openPanel('invite', `<div class="phead"><h3>${esc(g.name)}</h3><button class="btn" data-close>Close</button></div>
    <div><h4>Invite friends</h4>
      <div class="codebox"><span>${g.code}</span><button class="btn primary" id="cpLink">${navigator.share ? 'Share link' : 'Copy link'}</button></div>
      <p class="small" style="margin:8px 0 0">They open the link, or tap “Groups” and type the code.</p></div>
    <div><h4>Or find them by username</h4>
      <label class="search"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg><input id="uq" placeholder="Username…" autocapitalize="none" spellcheck="false" autocomplete="off"></label>
      <div id="uRes" class="ures"></div></div>
    <div><h4>In this group</h4><div class="chips">${g.members.map(m => avatar(m) + `<span class="mname">${esc(m)}${m === g.owner ? ' ★' : ''}</span>`).join('')}</div></div>
    <div><h4>Privacy</h4><label class="switch"><input type="checkbox" id="privT"${Cloud.priv ? ' checked' : ''}><span>Hide my list from the others for now</span></label>
      <p class="small" style="margin:6px 0 0">Good for blind ranking: everyone ranks first, then you all switch this off and compare.</p></div>
    <div class="stack"><button class="btn danger" id="leaveG">Leave this group</button></div>`);
  $('#cpLink').onclick = async () => {
    if(navigator.share){ try{ await navigator.share({ title: 'Tier Vault', text: `Rank drinks with me in “${g.name}”`, url: link }); return; }catch(e){ if(e.name === 'AbortError') return; } }
    toast(await copyText(link) ? 'Link copied' : link);
  };
  let t; const uq = $('#uq');
  uq.oninput = () => { clearTimeout(t); const q = uq.value.trim(); const box = $('#uRes');
    if(q.length < 2){ box.innerHTML = ''; return; }
    t = setTimeout(async () => { try{ const r = await api('search', { q: { q } });
      box.innerHTML = r.users.length ? r.users.map(u => `<div class="grow">${avatar(u)}<b style="flex:1">${esc(u)}</b>${g.members.includes(u) ? '<span class="small">in group</span>' : `<button class="btn" data-inv="${esc(u)}">Invite</button>`}</div>`).join('') : '<span class="small">Nobody found.</span>';
      box.querySelectorAll('[data-inv]').forEach(b => b.onclick = async () => { b.disabled = true;
        try{ await api('ginvite', { body: { code: g.code, user: b.dataset.inv } }); b.textContent = 'Invited ✓'; }catch(x){ toast(x.message); b.disabled = false; } });
    }catch(x){ box.innerHTML = `<span class="small">${esc(x.message)}</span>`; } }, 400); };
  $('#privT').onchange = e => { Cloud.priv = e.target.checked; saveGroupList(Object.keys(CATS)[0]); toast(Cloud.priv ? 'Your list is hidden from the others' : 'The others can see your list again'); };
  $('#leaveG').onclick = () => arm($('#leaveG'), 'Click again to leave', async () => {
    try{ await api('gleave', { body: { code: g.code } }); Cloud.groups = Cloud.groups.filter(x => x.code !== g.code); closeSheet(); leaveGroupView(); toast('You left the group'); }catch(x){ toast(x.message); } });
}

/* ---------- rendering helpers used by app.js ---------- */
function avatar(u, extra){ const h = hue(u); return `<span class="av" style="background:hsl(${h},60%,45%)"${extra || ''} title="${esc(u)}">${esc(u[0].toUpperCase())}</span>`; }
function shownFriends(){ return Object.keys(Cloud.others).filter(u => !Cloud.hide.has(u)); }
function groupTiers(e){ return (Cloud.group.tiers && Cloud.group.tiers.length) ? Cloud.group.tiers : ((e.list && e.list.tiers) || []); }
function cloudPrep(){            // where did each friend put each item?
  Cloud.peek = {};
  if(!Cloud.group || Cloud.view !== 'peek') return;
  for(const u of shownFriends()){ const e = Cloud.others[u]; if(!e || !e.list || !e.list.rank) continue;
    for(const t of groupTiers(e)) for(const id of (e.list.rank[t.id] || [])) (Cloud.peek[id] = Cloud.peek[id] || []).push({ u, t }); }
}
function peekHTML(id){
  const p = Cloud.peek[id]; if(!p) return '';
  return `<span class="pk">${p.slice(0, 4).map(x => `<span class="pkd" style="background:${x.t.color};color:${textOn(x.t.color)}" title="${esc(x.u)}: ${esc(x.t.label)}">${esc(x.u[0].toUpperCase())}</span>`).join('')}${p.length > 4 ? `<span class="pkd more">+${p.length - 4}</span>` : ''}</span>`;
}
function cloudButtonsHTML(){
  const n = Cloud.invites.length;
  const groupsBtn = Cloud.group ? `<button class="btn" id="cInvite"><span aria-hidden="true">＋</span><span class="txt">Invite</span></button>`
    : `<button class="btn" id="cGroups"><span aria-hidden="true">👥</span><span class="txt">Groups</span>${n ? `<span class="badge">${n}</span>` : ''}</button>`;
  const acct = Cloud.user ? '' : `<button class="btn primary" id="cLogin"><span class="txt">Log in</span><span aria-hidden="true" class="only-small">👤</span></button>`;
  return groupsBtn + acct;
}
function groupStripHTML(){
  const g = Cloud.group, fr = Object.keys(Cloud.others);
  const views = [['mine', 'Mine', 'Only your list'], ['peek', 'Peek', 'Your list, with little dots where friends put each drink'], ['both', 'Both', 'Your list and the others below it'], ['theirs', 'Theirs', 'Only the others’ lists']];
  return `<div class="gstrip">
    <div class="chips">${avatar(Cloud.user, ' data-me')}${fr.map(u => `<button class="chip${Cloud.hide.has(u) ? ' off' : ''}" data-who="${esc(u)}" title="Show or hide ${esc(u)}">${avatar(u)}<span>${esc(u)}</span>${Cloud.others[u].private ? ' 🔒' : ''}</button>`).join('')}
      ${fr.length ? '' : `<button class="btn primary" id="cInvite2">Invite friends</button><span class="small">Just you so far.</span>`}</div>
    <span class="spacer"></span>
    ${fr.length ? `<div class="seg" role="group" aria-label="What you see">${views.map(([k, l, t]) => `<button data-view="${k}" aria-pressed="${Cloud.view === k}" title="${t}">${l}</button>`).join('')}</div>` : ''}
  </div>`;
}
function othersBoardsHTML(cat){
  const fr = shownFriends(); if(!fr.length) return Object.keys(Cloud.others).length ? '<div class="hint">Tap a name above to show their list.</div>' : '';
  const base = ITEMS[cat].map(a => ({ id: a[0], t: a[1], x: a[2], y: a[3] || '' }));
  return fr.map(u => {
    const e = Cloud.others[u];
    const head = `<div class="ohead">${avatar(u)}<b>${esc(u)}</b>`;
    if(e.private) return head + `</div><div class="board ro" data-ro><div class="hint" style="padding:14px">${esc(u)} is keeping their list hidden for now 🔒</div></div>`;
    const L = e.list; if(!L || !L.rank) return head + `</div><div class="board ro" data-ro><div class="hint" style="padding:14px">${esc(u)} has not ranked anything yet.</div></div>`;
    const byId = Object.fromEntries(base.concat((L.custom || []).map(c => ({ id: c.id, t: c.t, y: c.y || '', custom: true }))).map(i => [i.id, i]));
    const tiers = groupTiers(e); let n = 0;
    const rows = tiers.map(t => { const ids = (L.rank[t.id] || []).filter(id => byId[id]); n += ids.length;
      return `<div class="row"><div class="label" style="background:${t.color};color:${textOn(t.color)}"><span>${esc(t.label)}</span><span class="n">${ids.length}</span></div><div class="zone" data-ro>${ids.map(id => cardHTML(cat, byId[id], 'ro')).join('')}</div></div>`; }).join('');
    return head + `<span class="counts">${n} ranked</span></div><div class="board ro" data-ro>${rows}</div>`;
  }).join('');
}
function bindCloud(){
  const on = (id, fn) => { const el = $('#' + id); if(el) el.onclick = fn; };
  on('cGroups', openGroups); on('cLogin', () => welcome()); on('cInvite', openInvite); on('cInvite2', openInvite); on('leaveGroup', leaveGroupView);
  document.querySelectorAll('#app [data-view]').forEach(b => b.onclick = () => { Cloud.view = b.dataset.view; lsSet('tv_view', Cloud.view); selected = null; hideMovebar(); renderCategory(); startPoll(); });
  document.querySelectorAll('#app [data-who]').forEach(b => b.onclick = () => { const u = b.dataset.who;
    Cloud.hide.has(u) ? Cloud.hide.delete(u) : Cloud.hide.add(u); renderCategory(); });
}
function cloudStatus(){
  if(Cloud.group){ const n = Object.keys(Cloud.others).length; return `<span class="status ok"><i></i>${n ? 'Live with ' + n + (n > 1 ? ' friends' : ' friend') : 'Group list'}</span>`; }
  if(Cloud.user) return `<span class="status ok"><i></i>Saved to <b style="margin-left:3px">${esc(Cloud.user)}</b></span>`;
  return `<span class="status local"><i></i>Guest · saved in this browser</span>`;
}

/* ---------- after the first render: links, welcome ---------- */
Cloud.afterBoot = function(){
  const sp = new URLSearchParams(location.search); const join = sp.get('join'), g = sp.get('g');
  if(join){
    if(Cloud.user){ history.replaceState(null, '', location.pathname); joinGroup(join); }
    else welcome('You were invited to a group list. Log in or create an account to join, it only takes a username and a password.');
    return;
  }
  if(g && Cloud.user){ openGroup(g); return; }
  if(!Cloud.user && !Cloud.down && !lsGet('tv_seen')) welcome();
};
