/* Tier Vault – Drinks: product search (Open Food Facts), generated can art, automatic product photos */
const DRINK_META = (window.TV_DATA && window.TV_DATA.meta) || {};
const OFF = 'https://world.openfoodfacts.org';
const OFF_FIELDS = 'code,product_name,product_name_en,product_name_de,brands,image_front_url,image_front_small_url,quantity';
const fold = s => String(s||'').normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
let lastUserSearch = 0;

async function offJSON(url){
  let r;
  try{ r = await withTimeout(fetch(url), 15000); }
  catch(e){ return await getJSON(url); }          // blocked or offline in the webview: try curl
  if(r.status===429||r.status===503){ const e=new Error('rate'); e.rate=true; throw e; }
  if(!r.ok) throw new Error('http '+r.status);
  return await r.json();
}
function offName(p){
  const brand = (p.brands||'').split(',')[0].trim();
  let name = (p.product_name_en||p.product_name||p.product_name_de||'').trim();
  if(!name) name = brand;
  if(brand && !fold(name).includes(fold(brand))) name = brand+' '+name;
  return name.replace(/\s+/g,' ').trim();
}
async function offSearch(q){
  lastUserSearch = Date.now();
  const j = await offJSON(`${OFF}/cgi/search.pl?search_terms=${encodeURIComponent(q)}&search_simple=1&action=process&json=1&page_size=30&sort_by=unique_scans_n&fields=${OFF_FIELDS}`);
  const seen = new Set(); const out = [];
  for(const p of (j.products||[])){
    const title = offName(p); if(!title) continue;
    const k = fold(title)+'|'+fold(p.quantity||''); if(seen.has(k)) continue; seen.add(k);
    const big = p.image_front_url||null, small = p.image_front_small_url||big;
    out.push({key:'off:'+p.code, title, year:'', sub:p.quantity||'', source:'Open Food Facts', preview:small, imgs:big?[big]:[]});
  }
  return out.sort((a,b)=>(!!b.preview)-(!!a.preview)).slice(0,16);
}

/* ---- pick the right product photo for a catalog drink ---- */
function matches(p, m){
  const t = ' '+fold([p.product_name,p.product_name_en,p.product_name_de,p.brands].join(' '))+' ';
  const compact = t.replace(/ /g,'');
  for(const tok of (m.must||[])){ if(!tok.split('|').some(a=>compact.includes(fold(a).replace(/ /g,'')))) return false; }
  for(const tok of (m.not||[])){ if(compact.includes(fold(tok).replace(/ /g,''))) return false; }
  return true;
}
async function offFindImage(m){
  if(m.code){
    try{
      const j = await offJSON(`${OFF}/api/v2/product/${m.code}.json?fields=${OFF_FIELDS}`);
      if(j && j.product && j.product.image_front_url) return {url:j.product.image_front_url};
    }catch(e){ if(e.rate) throw e; }
  }
  const j = await offJSON(`${OFF}/cgi/search.pl?search_terms=${encodeURIComponent(m.q)}&search_simple=1&action=process&json=1&page_size=40&sort_by=unique_scans_n&fields=${OFF_FIELDS}`);
  const ps = (j.products||[]).filter(p=>p.image_front_url && matches(p,m));
  if(!ps.length) return {url:null, searched:true};
  const multi = p => /\d\s*[x×]\s*\d/i.test(p.quantity||'') || /\bpack\b/i.test(p.product_name||'');
  ps.sort((a,b)=>multi(a)-multi(b));          // single cans/bottles first, keep popularity order otherwise
  return {url:ps[0].image_front_url};
}

/* ---- v2: product photos are bundled; drop the random photos the first version fetched automatically ---- */
async function drinksMigrate(){
  const v = await Store.read('drinks-version');
  if(v && v.v >= 2) return;
  let n = 0; for(const id of Object.keys(covers)){ if(DRINK_META[id] || /^d-/.test(id)){ delete covers[id]; n++; } }
  if(n) await Store.write('covers', covers);
  await Store.write('drinks-version', {v:2});
}

/* ---- automatic product photos: runs quietly in the background, gentle on the free database ---- */
const sleep = ms => new Promise(r=>setTimeout(r,ms));
let autoRunning = false;
async function startAutoCovers(){
  if(autoRunning || !Object.keys(DRINK_META).length) return; autoRunning = true;
  const miss = (await Store.read('autocovers')) || {};
  const now = Date.now();
  const cat = Object.keys(CATS)[0];
  const order = id => { const it = catItems(cat).find(i=>i.id===id); return it && (inPool(cat,it)||rankedIds(cat).has(id)) ? 0 : 1; };
  const queue = Object.keys(DRINK_META)
    .filter(id => DRINK_META[id].q && !covers[id] && !(miss[id] && now-miss[id] < 3*864e5))
    .sort((a,b)=>order(a)-order(b));
  let pause = 0;
  for(const id of queue){
    if(covers[id]) continue;                         // a cover was set by hand meanwhile
    while(Date.now()-lastUserSearch < 8000) await sleep(2000);   // let the search box go first
    const m = DRINK_META[id]; let res = null;
    try{ res = await offFindImage(m); }
    catch(e){ if(e.rate){ pause = 60000; } else { pause = 8000; } }
    if(res && res.url && !covers[id]){
      try{ covers[id] = await blobToPoster(await getBlob(res.url)); saveCovers(); refreshCard(id); }
      catch(e){}
    } else if(res && res.searched){ miss[id] = now; Store.write('autocovers', miss).catch(()=>{}); }
    await sleep(pause || 6500); pause = 0;           // Open Food Facts allows about 10 searches per minute
  }
  autoRunning = false;
}
function refreshCard(id){
  document.querySelectorAll(`.card[data-id="${CSS.escape(id)}"] img`).forEach(i=>{ i.src = covers[id]; });
}

/* ---- generated can art, shown until (or instead of) a real product photo ---- */
const artCache = {};
function shade(hex, f){
  const c = hex.replace('#',''); let r=parseInt(c.substr(0,2),16), g=parseInt(c.substr(2,2),16), b=parseInt(c.substr(4,2),16);
  const t = f<0?0:255, p = Math.abs(f);
  r = Math.round((t-r)*p+r); g = Math.round((t-g)*p+g); b = Math.round((t-b)*p+b);
  return '#'+[r,g,b].map(v=>v.toString(16).padStart(2,'0')).join('');
}
function wrapLines(x, text, maxW, maxLines){
  const words = text.split(' '); const lines = []; let cur = '';
  for(const w of words){ const t = cur?cur+' '+w:w; if(x.measureText(t).width<=maxW||!cur) cur=t; else { lines.push(cur); cur=w; } }
  if(cur) lines.push(cur);
  return lines.length<=maxLines ? lines : null;
}
function drinkArt(id){
  if(artCache[id]) return artCache[id];
  const m = DRINK_META[id]; if(!m) return null;
  const W=240, H=360, col=m.c||'#888888', ink=textOn(col);
  const c = document.createElement('canvas'); c.width=W; c.height=H; const x = c.getContext('2d');
  // backdrop
  const bg = x.createLinearGradient(0,0,0,H); bg.addColorStop(0, shade(col,-0.55)); bg.addColorStop(1, shade(col,-0.82));
  x.fillStyle = bg; x.fillRect(0,0,W,H);
  const glow = x.createRadialGradient(W/2,H*0.45,10,W/2,H*0.45,200); glow.addColorStop(0, col+'66'); glow.addColorStop(1, col+'00');
  x.fillStyle = glow; x.fillRect(0,0,W,H);
  // can
  const cx=48, cy=38, cw=144, ch=286, r=16;
  x.save(); x.shadowColor='rgba(0,0,0,.45)'; x.shadowBlur=24; x.shadowOffsetY=10;
  x.beginPath(); x.roundRect(cx,cy,cw,ch,r); x.fillStyle=col; x.fill(); x.restore();
  const body = x.createLinearGradient(cx,0,cx+cw,0);
  body.addColorStop(0,'rgba(0,0,0,.35)'); body.addColorStop(.18,'rgba(255,255,255,.10)'); body.addColorStop(.32,'rgba(255,255,255,.28)');
  body.addColorStop(.46,'rgba(255,255,255,0)'); body.addColorStop(.85,'rgba(0,0,0,.12)'); body.addColorStop(1,'rgba(0,0,0,.4)');
  x.beginPath(); x.roundRect(cx,cy,cw,ch,r); x.fillStyle=body; x.fill();
  // metal top and bottom
  const metal = y0 => { const g=x.createLinearGradient(cx,0,cx+cw,0); g.addColorStop(0,'#8d939b'); g.addColorStop(.35,'#f2f4f6'); g.addColorStop(.6,'#c3c8ce'); g.addColorStop(1,'#7a8088'); return g; };
  x.beginPath(); x.roundRect(cx,cy,cw,20,[r,r,4,4]); x.fillStyle=metal(); x.fill();
  x.beginPath(); x.roundRect(cx,cy+ch-14,cw,14,[4,4,r,r]); x.fillStyle=metal(); x.fill();
  x.fillStyle='rgba(0,0,0,.18)'; x.fillRect(cx,cy+20,cw,2); x.fillRect(cx,cy+ch-16,cw,2);
  // brand
  x.fillStyle = ink; x.textAlign='center'; x.textBaseline='middle';
  x.globalAlpha = .85; x.font = '700 13px Figtree, sans-serif';
  const brand = (m.b||'').toUpperCase();
  x.fillText(brand.length>22?brand.slice(0,21)+'…':brand, W/2, cy+44);
  x.globalAlpha = .5; x.fillRect(W/2-18, cy+57, 36, 2); x.globalAlpha = 1;
  // flavour, as big as it fits
  const text = (m.f||'').replace(/ · /g,' ').toUpperCase(); let lines=null, size=46;
  for(; size>=18; size-=2){ x.font = `800 ${size}px "Big Shoulders Display", sans-serif`; lines = wrapLines(x, text, cw-22, 3); if(lines) break; }
  if(!lines){ x.font='800 18px "Big Shoulders Display", sans-serif'; lines=[text.slice(0,20)]; size=18; }
  const lh = size*0.98, top = cy+ch*0.40 - (lines.length-1)*lh/2;
  lines.forEach((l,i)=>x.fillText(l, W/2, top+i*lh));
  let u = c.toDataURL('image/webp',0.86); if(!u.startsWith('data:image/webp')) u = c.toDataURL('image/png');
  return artCache[id] = u;
}
