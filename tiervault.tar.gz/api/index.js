// Tier Vault API – one function, Upstash Redis over REST, no dependencies.
const crypto = require('crypto');

const URL_ = process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL;
const TOKEN = process.env.KV_REST_API_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN;
const SECRET = process.env.TV_SECRET || TOKEN || 'dev';
const P = 'tv:'; // key prefix, so the database can be shared with other projects
const MAX_BODY = 900000;

async function redis(cmds) {
  const r = await fetch(URL_ + '/pipeline', {
    method: 'POST', headers: { Authorization: 'Bearer ' + TOKEN, 'Content-Type': 'application/json' },
    body: JSON.stringify(cmds)
  });
  if (!r.ok) throw new Error('redis ' + r.status);
  const out = await r.json();
  return out.map(x => { if (x.error) throw new Error(x.error); return x.result; });
}
const one = async cmd => (await redis([cmd]))[0];
const J = s => { try { return s ? JSON.parse(s) : null; } catch (e) { return null; } };

/* ---- auth: stateless signed token, scrypt passwords ---- */
const b64 = s => Buffer.from(s).toString('base64url');
function sign(u) {
  const body = b64(JSON.stringify({ u, e: Date.now() + 180 * 864e5 }));
  return body + '.' + crypto.createHmac('sha256', SECRET).update(body).digest('base64url');
}
function verify(t) {
  if (!t) return null; const [body, sig] = t.split('.');
  if (!body || !sig) return null;
  const want = crypto.createHmac('sha256', SECRET).update(body).digest('base64url');
  if (sig.length !== want.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(want))) return null;
  const p = J(Buffer.from(body, 'base64url').toString()); return p && p.e > Date.now() ? p.u : null;
}
const hashPw = (pw, salt = crypto.randomBytes(12).toString('hex')) => salt + ':' + crypto.scryptSync(pw, salt, 32).toString('hex');
function checkPw(pw, stored) {
  const [salt, h] = String(stored).split(':'); if (!salt || !h) return false;
  const a = Buffer.from(hashPw(pw, salt).split(':')[1], 'hex'), b = Buffer.from(h, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
const UNAME = /^[a-z0-9_.]{3,20}$/;
const CODE_ABC = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const newCode = () => Array.from(crypto.randomBytes(6), b => CODE_ABC[b % CODE_ABC.length]).join('');

/* ---- groups ---- */
async function loadGroup(code, me) {
  const [meta, members, v] = await redis([['GET', P + 'r:' + code], ['SMEMBERS', P + 'rm:' + code], ['GET', P + 'rv:' + code]]);
  const room = J(meta); if (!room) return null;
  if (me && !members.includes(me)) return { forbidden: true };
  const raw = members.length ? await one(['MGET', ...members.map(m => P + 'rl:' + code + ':' + m)]) : [];
  const lists = {};
  members.forEach((m, i) => {
    const e = J(raw[i]) || {};
    lists[m] = (m !== me && e.list && e.list.private) ? { private: 1 } : e;
  });
  return { v: +v || 0, room: { code, name: room.name, owner: room.owner, tiers: room.tiers, type: room.type || 'drinks', members }, lists };
}
const bump = code => ['INCR', P + 'rv:' + code];
const cleanTiers = t => Array.isArray(t) ? t.slice(0, 20).map(x => ({ id: String(x.id).slice(0, 30), label: String(x.label || '').slice(0, 40), color: /^#[0-9a-f]{6}$/i.test(x.color) ? x.color : '#888888' })) : null;

module.exports = async (req, res) => {
  const send = (code, obj) => { res.setHeader('Cache-Control', 'no-store'); res.status(code).json(obj); };
  if (!URL_ || !TOKEN) return send(503, { error: 'Online features are not set up yet.' });
  const a = String(req.query.a || '');
  let body = req.body || {};
  if (typeof body === 'string') body = J(body) || {};
  if (JSON.stringify(body).length > MAX_BODY) return send(413, { error: 'That is too big to save.' });
  try {
    /* ---- open endpoints ---- */
    if (a === 'register' || a === 'login') {
      const u = String(body.u || '').trim().toLowerCase(), p = String(body.p || '');
      if (!UNAME.test(u)) return send(400, { error: 'Username: 3–20 letters, numbers, _ or .' });
      if (p.length < 4) return send(400, { error: 'Password: at least 4 characters.' });
      if (a === 'register') {
        const ok = await one(['SET', P + 'u:' + u, JSON.stringify({ pw: hashPw(p), at: Date.now() }), 'NX']);
        if (!ok) return send(409, { error: 'That username is taken.' });
        await one(['ZADD', P + 'users', 0, u]);
        return send(200, { token: sign(u), u });
      }
      const [rec, fails] = await redis([['GET', P + 'u:' + u], ['GET', P + 'fail:' + u]]);
      if (+fails >= 10) return send(429, { error: 'Too many tries. Wait 10 minutes.' });
      const user = J(rec);
      if (!user || !checkPw(p, user.pw)) { await redis([['INCR', P + 'fail:' + u], ['EXPIRE', P + 'fail:' + u, 600]]); return send(401, { error: user ? 'Wrong password.' : 'No account with that name.' }); }
      return send(200, { token: sign(u), u });
    }

    const me = verify(String(req.headers.authorization || '').replace(/^Bearer /, ''));
    if (!me) return send(401, { error: 'Please log in again.' });
    const code = String(req.query.code || body.code || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);

    switch (a) {
      case 'me': {
        const [data, cov, rooms, invites] = await redis([['GET', P + 'me:' + me], ['GET', P + 'cov:' + me], ['SMEMBERS', P + 'ur:' + me], ['SMEMBERS', P + 'inv:' + me]]);
        const codes = [...rooms, ...invites];
        const metas = codes.length ? await one(['MGET', ...codes.map(c => P + 'r:' + c)]) : [];
        const info = c => { const m = J(metas[codes.indexOf(c)]); return m && { code: c, name: m.name, owner: m.owner, type: m.type || 'drinks' }; };
        return send(200, { u: me, data: J(data), covers: J(cov), groups: rooms.map(info).filter(Boolean), invites: invites.map(info).filter(Boolean) });
      }
      case 'save': {
        const key = body.what === 'covers' ? 'cov:' : 'me:';
        await one(['SET', P + key + me, JSON.stringify(body.obj || {})]);
        return send(200, { ok: 1 });
      }
      case 'search': {
        const q = String(req.query.q || '').toLowerCase().replace(/[^a-z0-9_.]/g, '');
        if (q.length < 2) return send(200, { users: [] });
        const users = await one(['ZRANGE', P + 'users', '[' + q, '[' + q + '\xff', 'BYLEX', 'LIMIT', 0, 8]);
        return send(200, { users: users.filter(x => x !== me) });
      }
      case 'gcreate': {
        const name = String(body.name || '').trim().slice(0, 40) || 'Group list';
        const tiers = cleanTiers(body.tiers) || [];
        const type = /^[a-z]{2,12}$/.test(body.type) ? body.type : 'custom';
        let c = newCode();
        for (let i = 0; i < 5 && !(await one(['SET', P + 'r:' + c, JSON.stringify({ name, owner: me, tiers, type, at: Date.now() }), 'NX'])); i++) c = newCode();
        await redis([['SADD', P + 'rm:' + c, me], ['SADD', P + 'ur:' + me, c], bump(c)]);
        return send(200, await loadGroup(c, me));
      }
      case 'gjoin': {
        if (!(await one(['EXISTS', P + 'r:' + code]))) return send(404, { error: 'No group with that code.' });
        await redis([['SADD', P + 'rm:' + code, me], ['SADD', P + 'ur:' + me, code], ['SREM', P + 'inv:' + me, code], bump(code)]);
        return send(200, await loadGroup(code, me));
      }
      case 'gdecline': await one(['SREM', P + 'inv:' + me, code]); return send(200, { ok: 1 });
      case 'ginvite': {
        const to = String(body.user || '').toLowerCase();
        const [isMember, exists] = await redis([['SISMEMBER', P + 'rm:' + code, me], ['EXISTS', P + 'u:' + to]]);
        if (!isMember) return send(403, { error: 'You are not in this group.' });
        if (!exists) return send(404, { error: 'No user with that name.' });
        await one(['SADD', P + 'inv:' + to, code]);
        return send(200, { ok: 1 });
      }
      case 'gleave': {
        await redis([['SREM', P + 'rm:' + code, me], ['SREM', P + 'ur:' + me, code], ['DEL', P + 'rl:' + code + ':' + me], bump(code)]);
        return send(200, { ok: 1 });
      }
      case 'gget': case 'gpoll': {
        if (a === 'gpoll') {
          const v = +(await one(['GET', P + 'rv:' + code])) || 0;
          if (v === +req.query.v) return send(200, { same: 1 });   // nothing changed: tiny reply, one Redis read
        }
        const g = await loadGroup(code, me);
        if (!g) return send(404, { error: 'This group does not exist any more.' });
        if (g.forbidden) return send(403, { error: 'You are not in this group.' });
        return send(200, g);
      }
      case 'gsave': {
        const [isMember, meta] = await redis([['SISMEMBER', P + 'rm:' + code, me], ['GET', P + 'r:' + code]]);
        if (!isMember) return send(403, { error: 'You are not in this group.' });
        const cmds = [['SET', P + 'rl:' + code + ':' + me, JSON.stringify({ list: body.list || {}, cov: body.cov || {} })], bump(code)];
        const room = J(meta); const tiers = cleanTiers(body.tiers);
        if (room && tiers && room.owner === me) { room.tiers = tiers; if (body.name) room.name = String(body.name).slice(0, 40); cmds.unshift(['SET', P + 'r:' + code, JSON.stringify(room)]); }
        const r = await redis(cmds);
        return send(200, { v: r[r.length - 1] });
      }
    }
    return send(404, { error: 'Unknown action' });
  } catch (e) {
    console.error(e);
    return send(500, { error: 'Server problem. Try again in a moment.' });
  }
};
